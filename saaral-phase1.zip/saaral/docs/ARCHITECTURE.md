# SAARAL – Architecture (Phase 1)

## 1. Requirements in brief
- **Functional:** customer app, provider app, admin dashboard; discover → book → provider accepts → service → OTP completion → payment → commission → review.
- **Non-functional:** secure by default, mobile-first, Tamil + English, configurable catalog/commission, no double bookings or double payments.
- **Constraints:** small team, launch in one city → **modular monolith**, REST, PostgreSQL.

## 2. Folder structure
```
saaral/
├── README.md
├── docs/ARCHITECTURE.md
├── backend/                      Django + DRF (Phase 1 – built)
│   ├── manage.py  pytest.ini  requirements*.txt  .env.example  docker-compose.yml
│   ├── config/                   settings, settings_test, urls, wsgi/asgi
│   ├── scripts/static_check.py   dependency-free structural check
│   └── apps/
│       ├── core/                 BaseModel, PlatformSetting, AuditLog, roles, permissions,
│       │                         error envelope, commission rules, utils, seed_demo
│       ├── accounts/             User, PhoneOTP, OTP + Firebase + staff login, JWT
│       ├── customers/            CustomerProfile, Address
│       ├── providers/            ProviderProfile, ProviderDocument, ProviderService, Availability
│       ├── catalog/              ServiceCategory, Service, ServiceArea
│       ├── bookings/             Booking, BookingStatusHistory, BookingOTP, Review, state machine
│       ├── payments/             Payment, Refund, Commission, ProviderPayout
│       ├── notifications/        Notification, DeviceToken (FCM)
│       ├── support/              Complaint
│       └── promotions/           Coupon, Referral
├── mobile/customer_app/          Flutter + Riverpod + Dio      (Phase 3)
├── mobile/provider_app/          Flutter + Riverpod + Dio      (Phase 4)
└── admin-dashboard/              Next.js + TypeScript          (Phase 5)
```

## 3. System view
```
 Customer app ─┐                     ┌─ Firebase Auth (phone OTP)  ← client SDK
 Provider app ─┼─ HTTPS/JSON ─► Django REST API ─┬─ PostgreSQL (+PostGIS-ready)
 Admin web ────┘   (JWT)        (modular monolith) ├─ Redis (cache, throttles)
                                                   ├─ FCM (push)        [Phase 6]
                                                   ├─ Payment gateway   [Phase 6, sandbox]
                                                   └─ Maps (Mappls/Google) [Phase 3]
```
Modules talk through service functions, never through each other's views. Dependency direction: `core ← accounts, customers, catalog ← providers ← bookings ← payments`; `accounts` reaches profiles only via `ensure_role_profile`.

## 4. Key decisions & trade-offs
| Decision | Why | Revisit when |
|---|---|---|
| Modular monolith | One deploy, simple transactions for booking+payment | Teams/traffic force independent scaling |
| UUID primary keys | Non-enumerable IDs (defence in depth; object checks still required) | – |
| One `User` table, one role per phone | Simple RBAC; separate customer/provider apps | Users need both roles → introduce role memberships |
| Customers/providers: phone OTP; staff: email+password | Matches Indian mobile UX; staff need passwords | Add 2FA for staff (recommended before launch) |
| Firebase token exchange **and** backend OTP | Firebase for production OTP delivery; backend OTP keeps dev/test hermetic | Drop backend OTP if Firebase-only |
| Lat/lng decimals + haversine, not PostGIS yet | Tests run on SQLite; DB image already PostGIS | Provider search needs radius queries at scale |
| Money as `Decimal` rupees | Simple, exact | Multi-currency |
| Completion OTP derived by HMAC(booking, nonce) | App can display it; nothing guessable stored | – |
| Commission precedence: provider > category > `PlatformSetting` > env | "Configurable, not hard-coded" | – |
| State machine as pure functions (`bookings/state.py`) | Testable; service layer must lock row + record history | – |

## 5. Authentication flow
```
Customer/Provider (dev/backend OTP)          Customer/Provider (Firebase)
 POST otp/request {phone} ─► HMAC(code) stored   App: Firebase SDK sends/verifies SMS
 POST otp/verify {phone,code,role}               POST firebase/ {id_token, role}
   └─ single-use, ≤5 attempts, 5-min TTL           └─ firebase_admin.verify_id_token (revocation checked)
        └────────────► login_or_register (role fixed at first login) ◄────────────┘
                              └─► JWT access (15 min) + rotating refresh (blacklist on rotate/logout)
Staff: POST admin/login {email,password} ─► role ∈ {admin,support,finance} ─► audit-logged, throttled 5/min/IP
```

## 6. Role permissions (enforced in `apps/core/permissions.py`)
| Capability | customer | provider | support | finance | admin |
|---|---|---|---|---|---|
| Own profile/addresses/bookings | ✔ | – | – | – | – |
| Own provider profile/jobs/earnings | – | ✔ | – | – | – |
| View any customer/provider/booking | – | – | ✔ | ✔ (money) | ✔ |
| Verify providers, manage catalog/areas/pricing | – | – | – | – | ✔ |
| Complaints & disputes | own | own | ✔ | – | ✔ |
| Refunds, payouts, commission | – | – | – | ✔ | ✔ |
| Cancel in-progress booking | – | – | ✔ | – | ✔ |
Object-level access uses `owner_user_id` + `IsOwnerOrStaff`. JWT claims are informational; the DB user is authoritative.

## 7. Data integrity guards already in the schema
- One captured payment per booking (partial unique constraint); gateway payment id unique.
- Booking idempotency key unique per customer; scheduled bookings require a start time.
- Inspection-first services may omit price; all others must have one.
- One default address per customer; availability end > start; review rating 1–5; commission 0–100.
- Audit log append-only; verification files in private storage (no URL), only last-4 of ID numbers stored.

## 8. Business rules → where they live
- Commission configurable: `PlatformSetting('commission.default_percent')`, `ServiceCategory.commission_percent`, `ProviderProfile.commission_percent`.
- "Don't claim availability": `ServiceArea.is_serviceable` is only a launch switch; Phase 3 search must also require approved + online providers with matching service, area and `Availability` rows. No availability rows ⇒ not available.
- Charges before confirmation: `Booking.charges_snapshot` + amount columns are frozen at booking time (Phase 3).

## 9. Known gaps / to revisit
2FA for staff; real SMS provider; Redis in production; PostGIS migration; document virus-scan & signed-download view (Phase 2); bank-detail storage design (Phase 6); data-retention/erasure flow (DPDP Act); Tamil copy review.
