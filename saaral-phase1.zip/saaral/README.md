# SAARAL (சாரல்) – Services near you

Hyperlocal service-booking marketplace. Launch market: **Coimbatore, Tamil Nadu**.
This repository is built in phases. **Current: Phase 1 – project structure, database, authentication.**

| Phase | Scope | Status |
|---|---|---|
| 1 | Structure, database schema, authentication | **Source written – not yet run (see below)** |
| 2 | Service catalog & provider onboarding | – |
| 3 | Customer discovery & booking | – |
| 4 | Provider booking management | – |
| 5 | Admin dashboard (Next.js) | – |
| 6 | Payments, commission, notifications | – |
| 7 | Testing, security hardening, deployment prep | – |

## Verification status (read this first)

Phase 1 was written in a sandbox with **no Django installed and no network**, so:

| Item | Status |
|---|---|
| All Python files compile; model relations resolve (`scripts/static_check.py`) | ✅ checked |
| `makemigrations`, `migrate`, `manage.py check` | ❌ **not run** – no migrations are committed yet |
| pytest suite (62 test functions) | ❌ **not run** |
| Firebase token verification against real Firebase | ❌ not tested (mocked in tests) |
| Payments, FCM, maps | not in Phase 1 |

Expect to fix a few small errors on first run. Run the commands below and report failures; Phase 2 should not start until they pass.

## Quick start (backend)

Prerequisites: Python 3.12+, Docker (optional – or use SQLite for a first run).

```bash
cd backend
python -m venv .venv && source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements-dev.txt
cp .env.example .env                                      # edit values; never commit .env
```

**Database option A – PostgreSQL/PostGIS via Docker**
```bash
docker compose up -d db redis
```
**Database option B – quick local start with SQLite:** set `USE_SQLITE=1` in `.env`.

```bash
python scripts/static_check.py          # structural sanity check (no Django needed)
python manage.py check
python manage.py makemigrations         # FIRST RUN ONLY – then commit the generated apps/*/migrations/0001_initial.py
python manage.py makemigrations --check # must report "No changes detected"
python manage.py migrate
python manage.py seed_demo              # local-only demo data (refuses when DJANGO_DEBUG=False)
python manage.py runserver
pytest                                   # run the test-suite
```

- API docs (Swagger): http://localhost:8000/api/docs/ · OpenAPI schema: `/api/schema/`
- Health: `/health/`, `/health/ready/`
- Django admin (dev inspection only): `/django-admin/`

## Phase 1 API

| Method & path | Who | Purpose |
|---|---|---|
| `POST /api/v1/auth/otp/request/` | public | Send phone OTP (**simulated SMS in dev**) |
| `POST /api/v1/auth/otp/verify/` | public | Verify OTP → JWT. Body: `phone, code, role(customer\|provider), full_name?` |
| `POST /api/v1/auth/firebase/` | public | Exchange Firebase phone-auth ID token → JWT (needs `FIREBASE_CREDENTIALS_FILE`) |
| `POST /api/v1/auth/admin/login/` | staff | Email + password for dashboard roles |
| `POST /api/v1/auth/token/refresh/` | token | Rotate refresh token |
| `POST /api/v1/auth/logout/` | any | Blacklist refresh token |
| `GET/PATCH /api/v1/auth/me/` | any | Profile (`full_name, email, preferred_language`) |

Errors always look like `{"error": {"code": "...", "message": "...", "details": {...}}}`.

Try it (dev mode, after `seed_demo`):
```bash
curl -X POST localhost:8000/api/v1/auth/otp/request/ -H 'Content-Type: application/json' -d '{"phone":"9999900001"}'
curl -X POST localhost:8000/api/v1/auth/otp/verify/  -H 'Content-Type: application/json' \
     -d '{"phone":"9999900001","code":"123456","role":"customer"}'
```

## Demo accounts (LOCAL ONLY)

Created by `seed_demo`; the command refuses to run unless `DJANGO_DEBUG=True`.

| Role | Login |
|---|---|
| Customer | phone `+919999900001`, OTP `123456` (dev mode) |
| Provider (approved, online, Mon–Sat 9–6, RS Puram / Gandhipuram / Race Course) | phone `+919999900002`, OTP `123456` |
| Admin | `admin@saaral.local`, password printed once by `seed_demo` (or set `DEMO_ADMIN_PASSWORD`) |

All prices, PIN codes and coordinates in the seed are **placeholders**. Tamil copy needs native-speaker review.

## Simulated / not-real features (Phase 1)

- **SMS OTP** – `ConsoleSMSBackend` logs the code; it raises unless `AUTH_DEV_MODE=True`, and settings refuse `AUTH_DEV_MODE` when `DJANGO_DEBUG` is false. Production should use Firebase phone auth or a real SMS provider class (`SMS_BACKEND`).
- **Fixed dev OTP** (`OTP_DEV_FIXED_CODE`) – same guard.

## Security notes

Secrets only via environment; `.env` is git-ignored. JWT access 15 min, rotating + blacklisted refresh tokens. OTPs are stored as HMACs, expire, are single-use, attempt-limited and rate-limited (per phone in DB, per IP via DRF throttles). Roles are enforced from the DB user on every request. Provider documents use private storage with no URL. Audit log is append-only at ORM level. See `docs/ARCHITECTURE.md`.

**Before production:** use Redis (`REDIS_URL`) so throttles work across workers; set `NUM_PROXIES`/`DJANGO_BEHIND_PROXY` correctly; REVOKE UPDATE/DELETE on `core_auditlog` for the app DB role; pin dependencies (`pip freeze`).
