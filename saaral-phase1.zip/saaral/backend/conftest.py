from decimal import Decimal

import pytest
from django.core.cache import cache
from rest_framework.test import APIClient

from apps.accounts import services as account_services
from apps.accounts.models import User
from apps.core.roles import Role


@pytest.fixture(autouse=True)
def _clear_cache():
    cache.clear()
    yield
    cache.clear()


@pytest.fixture
def api_client():
    return APIClient()


@pytest.fixture
def make_user(db):
    counter = {"n": 0}

    def _make(role=Role.CUSTOMER, phone=None, **extra):
        counter["n"] += 1
        phone = phone or f"+9188888{counter['n']:05d}"
        if role in ("admin", "support", "finance") or role in (Role.ADMIN, Role.SUPPORT, Role.FINANCE):
            extra.setdefault("email", f"staff{counter['n']}@saaral.test")
        user = User.objects.create_user(phone=phone, role=role, is_phone_verified=True, **extra)
        account_services.ensure_role_profile(user)
        return user

    return _make


@pytest.fixture
def booking_factory(make_user):
    from apps.bookings.models import Booking
    from apps.catalog.models import Service, ServiceCategory
    from apps.customers.models import Address

    def _make(**overrides):
        customer_user = make_user(Role.CUSTOMER)
        category = ServiceCategory.objects.create(slug=f"cat-{customer_user.pk.hex[:6]}", name_en="Test category")
        service = Service.objects.create(
            category=category, slug="svc", name_en="Test service", pricing_type="fixed", base_price=Decimal("100")
        )
        address = Address.objects.create(
            customer=customer_user.customer_profile, line1="1 Test St", locality="RS Puram", pincode="641002"
        )
        defaults = dict(
            customer=customer_user.customer_profile, service=service, address=address, total_amount=Decimal("100")
        )
        defaults.update(overrides)
        return Booking.objects.create(**defaults)

    return _make
