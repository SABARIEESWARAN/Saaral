"""Test settings: SQLite, fast hashing, relaxed throttles, deterministic dev-OTP."""
import os
import tempfile

os.environ.setdefault("DJANGO_DEBUG", "True")
os.environ.setdefault("USE_SQLITE", "1")
os.environ.setdefault("AUTH_DEV_MODE", "True")
os.environ.setdefault("OTP_DEV_FIXED_CODE", "123456")
os.environ.setdefault("DJANGO_SECRET_KEY", "test-only-secret-key-not-for-any-real-use-0123456789")

from .settings import *  # noqa: E402,F401,F403

PASSWORD_HASHERS = ["django.contrib.auth.hashers.MD5PasswordHasher"]
CACHES = {"default": {"BACKEND": "django.core.cache.backends.locmem.LocMemCache"}}
REST_FRAMEWORK = {
    **REST_FRAMEWORK,  # noqa: F405
    "DEFAULT_THROTTLE_RATES": {k: "10000/min" for k in REST_FRAMEWORK["DEFAULT_THROTTLE_RATES"]},  # noqa: F405
}
OTP_RESEND_COOLDOWN_SECONDS = 0  # individual tests opt in to cooldown / hourly limits
OTP_MAX_REQUESTS_PER_HOUR = 1000
PRIVATE_MEDIA_ROOT = tempfile.mkdtemp(prefix="saaral-private-")
