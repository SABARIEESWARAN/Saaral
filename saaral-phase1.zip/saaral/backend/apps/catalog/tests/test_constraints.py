from decimal import Decimal

import pytest
from django.db import IntegrityError, transaction

from apps.catalog.models import Service, ServiceCategory

pytestmark = pytest.mark.django_db


@pytest.fixture
def category():
    return ServiceCategory.objects.create(slug="plumbing", name_en="Plumbing", name_ta="பிளம்பிங்")


def test_inspection_first_service_needs_no_price(category):
    Service.objects.create(category=category, slug="x", name_en="X", pricing_type="inspection_first", inspection_charge=Decimal("149"))


@pytest.mark.parametrize("pricing", ["fixed", "starting_from"])
def test_priced_services_require_base_price(category, pricing):
    with pytest.raises(IntegrityError), transaction.atomic():
        Service.objects.create(category=category, slug="y", name_en="Y", pricing_type=pricing)


def test_service_slug_unique_within_category(category):
    Service.objects.create(category=category, slug="s", name_en="S", base_price=Decimal("1"))
    with pytest.raises(IntegrityError), transaction.atomic():
        Service.objects.create(category=category, slug="s", name_en="S2", base_price=Decimal("1"))
