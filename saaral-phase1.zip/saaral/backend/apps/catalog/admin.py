from django.contrib import admin

from .models import Service, ServiceArea, ServiceCategory


@admin.register(ServiceCategory)
class ServiceCategoryAdmin(admin.ModelAdmin):
    list_display = ("name_en", "name_ta", "slug", "sort_order", "is_active", "commission_percent")
    prepopulated_fields = {"slug": ("name_en",)}


@admin.register(Service)
class ServiceAdmin(admin.ModelAdmin):
    list_display = ("name_en", "category", "pricing_type", "base_price", "inspection_charge", "is_active")
    list_filter = ("category", "pricing_type", "is_active")
    search_fields = ("name_en", "name_ta")


@admin.register(ServiceArea)
class ServiceAreaAdmin(admin.ModelAdmin):
    list_display = ("name", "city", "is_serviceable", "is_active")
    list_filter = ("city", "is_serviceable", "is_active")
    prepopulated_fields = {"slug": ("name",)}
