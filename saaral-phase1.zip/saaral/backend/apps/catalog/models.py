from decimal import Decimal

from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models
from django.db.models import Q

from apps.core.models import BaseModel
from apps.customers.models import latitude_field, longitude_field

PERCENT = [MinValueValidator(Decimal("0")), MaxValueValidator(Decimal("100"))]


class ServiceCategory(BaseModel):
    """Configurable catalog: add rows, no code change needed for new categories."""

    slug = models.SlugField(max_length=60, unique=True)
    name_en = models.CharField(max_length=100)
    name_ta = models.CharField(max_length=100, blank=True)
    description_en = models.TextField(blank=True)
    description_ta = models.TextField(blank=True)
    icon = models.CharField(max_length=50, blank=True, help_text="Icon key resolved by the mobile apps.")
    sort_order = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField(default=True)
    commission_percent = models.DecimalField(
        max_digits=5, decimal_places=2, null=True, blank=True, validators=PERCENT,
        help_text="Optional category override of the platform commission.",
    )

    class Meta:
        ordering = ["sort_order", "name_en"]
        verbose_name_plural = "service categories"

    def __str__(self):
        return self.name_en


class Service(BaseModel):
    class PricingType(models.TextChoices):
        FIXED = "fixed", "Fixed price"
        STARTING_FROM = "starting_from", "Starting from (estimate)"
        INSPECTION_FIRST = "inspection_first", "Inspection first (quote after visit)"

    class Unit(models.TextChoices):
        VISIT = "visit", "Per visit"
        KG = "kg", "Per kg"
        ITEM = "item", "Per item"

    category = models.ForeignKey(ServiceCategory, on_delete=models.PROTECT, related_name="services")
    slug = models.SlugField(max_length=80)
    name_en = models.CharField(max_length=120)
    name_ta = models.CharField(max_length=120, blank=True)
    description_en = models.TextField(blank=True)
    description_ta = models.TextField(blank=True)
    pricing_type = models.CharField(max_length=20, choices=PricingType.choices, default=PricingType.FIXED)
    unit = models.CharField(max_length=10, choices=Unit.choices, default=Unit.VISIT)
    base_price = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, validators=[MinValueValidator(Decimal("0"))])
    inspection_charge = models.DecimalField(max_digits=10, decimal_places=2, default=Decimal("0"), validators=[MinValueValidator(Decimal("0"))])
    estimated_duration_minutes = models.PositiveIntegerField(default=60)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["category__sort_order", "name_en"]
        constraints = [
            models.UniqueConstraint(fields=["category", "slug"], name="uniq_service_slug_per_category"),
            # Inspection-first services quote after the visit; every other type must show a price up front.
            models.CheckConstraint(
                condition=Q(pricing_type="inspection_first") | Q(base_price__isnull=False),
                name="priced_unless_inspection_first",
            ),
        ]

    def __str__(self):
        return self.name_en


class ServiceArea(BaseModel):
    """A serviceable zone. Coverage claims must ALSO be backed by active providers (see Phase 3)."""

    slug = models.SlugField(max_length=80, unique=True)
    name = models.CharField(max_length=120)
    city = models.CharField(max_length=80, default="Coimbatore")
    state = models.CharField(max_length=80, default="Tamil Nadu")
    pincodes = models.JSONField(default=list, blank=True)
    center_latitude = latitude_field()
    center_longitude = longitude_field()
    radius_km = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True, validators=[MinValueValidator(Decimal("0.1"))])
    is_serviceable = models.BooleanField(default=False, help_text="Launch switch. Off until ops has providers here.")
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ["city", "name"]
        indexes = [models.Index(fields=["city", "is_serviceable"])]

    def __str__(self):
        return f"{self.name}, {self.city}"
