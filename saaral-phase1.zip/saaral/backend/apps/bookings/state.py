"""Booking state machine – pure functions, no DB access, so it is trivially testable.

Services (Phase 3/4) must call `validate_transition` inside a transaction with the booking row locked.
"""
from django.db import models

from apps.core.roles import Role


class BookingStatus(models.TextChoices):
    REQUESTED = "requested", "Requested"
    ACCEPTED = "accepted", "Accepted"
    TRAVELLING = "travelling", "Travelling"
    ARRIVED = "arrived", "Arrived"
    IN_PROGRESS = "in_progress", "In progress"
    COMPLETED = "completed", "Completed"
    REJECTED = "rejected", "Rejected"
    CANCELLED = "cancelled", "Cancelled"
    EXPIRED = "expired", "Expired"


CUSTOMER, PROVIDER, STAFF, SYSTEM = "customer", "provider", "staff", "system"
_S = BookingStatus

# from_status -> {to_status: actors allowed to perform it}
TRANSITIONS = {
    _S.REQUESTED: {
        _S.ACCEPTED: {PROVIDER},
        _S.REJECTED: {PROVIDER},
        _S.CANCELLED: {CUSTOMER, STAFF},
        _S.EXPIRED: {SYSTEM},
    },
    _S.ACCEPTED: {_S.TRAVELLING: {PROVIDER}, _S.CANCELLED: {CUSTOMER, PROVIDER, STAFF}},
    _S.TRAVELLING: {_S.ARRIVED: {PROVIDER}, _S.CANCELLED: {CUSTOMER, PROVIDER, STAFF}},
    _S.ARRIVED: {_S.IN_PROGRESS: {PROVIDER}, _S.CANCELLED: {CUSTOMER, PROVIDER, STAFF}},
    # Completion is only reachable after the customer's booking-OTP is verified (service layer enforces it).
    _S.IN_PROGRESS: {_S.COMPLETED: {PROVIDER}, _S.CANCELLED: {STAFF}},
    _S.COMPLETED: {},
    _S.REJECTED: {},
    _S.CANCELLED: {},
    _S.EXPIRED: {},
}
TERMINAL_STATUSES = frozenset(s for s, nxt in TRANSITIONS.items() if not nxt)


class InvalidTransition(Exception):
    pass


def actor_for_role(role: str):
    return {Role.CUSTOMER.value: CUSTOMER, Role.PROVIDER.value: PROVIDER, Role.ADMIN.value: STAFF, Role.SUPPORT.value: STAFF}.get(role)


def allowed_next(status: str, actor: str) -> set:
    return {to for to, actors in TRANSITIONS.get(status, {}).items() if actor in actors}


def can_transition(from_status: str, to_status: str, actor: str) -> bool:
    return to_status in allowed_next(from_status, actor)


def validate_transition(from_status: str, to_status: str, actor: str) -> None:
    if not can_transition(from_status, to_status, actor):
        raise InvalidTransition(f"{actor!r} cannot move a booking from {from_status!r} to {to_status!r}.")
