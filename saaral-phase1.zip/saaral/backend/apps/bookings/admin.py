from django.contrib import admin

from .models import Booking, BookingOTP, BookingStatusHistory, Review


@admin.register(Booking)
class BookingAdmin(admin.ModelAdmin):
    list_display = ("reference", "status", "booking_type", "customer", "provider", "total_amount", "created_at")
    list_filter = ("status", "booking_type")
    search_fields = ("reference", "customer__user__phone")
    readonly_fields = ("reference", "address_snapshot", "charges_snapshot")


@admin.register(BookingStatusHistory)
class BookingStatusHistoryAdmin(admin.ModelAdmin):
    list_display = ("booking", "from_status", "to_status", "actor", "created_at")


@admin.register(BookingOTP)
class BookingOTPAdmin(admin.ModelAdmin):
    list_display = ("booking", "expires_at", "attempts", "verified_at")
    exclude = ("nonce",)


@admin.register(Review)
class ReviewAdmin(admin.ModelAdmin):
    list_display = ("booking", "provider", "rating", "status", "created_at")
    list_filter = ("status", "rating")
