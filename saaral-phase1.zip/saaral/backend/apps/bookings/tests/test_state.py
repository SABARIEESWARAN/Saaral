import pytest
from django.db import IntegrityError, transaction

from apps.bookings.state import (
    CUSTOMER, PROVIDER, STAFF, SYSTEM, TERMINAL_STATUSES, TRANSITIONS, BookingStatus as S,
    InvalidTransition, actor_for_role, allowed_next, can_transition, validate_transition,
)


def test_happy_path_by_provider():
    path = [S.REQUESTED, S.ACCEPTED, S.TRAVELLING, S.ARRIVED, S.IN_PROGRESS, S.COMPLETED]
    for a, b in zip(path, path[1:]):
        assert can_transition(a, b, PROVIDER)


def test_customer_cannot_advance_service_or_complete():
    for to in (S.ACCEPTED, S.TRAVELLING, S.ARRIVED, S.IN_PROGRESS, S.COMPLETED):
        assert not any(can_transition(frm, to, CUSTOMER) for frm in S)


def test_no_skipping_states():
    assert not can_transition(S.REQUESTED, S.IN_PROGRESS, PROVIDER)
    assert not can_transition(S.ACCEPTED, S.COMPLETED, PROVIDER)


def test_terminal_states_are_final():
    assert TERMINAL_STATUSES == {S.COMPLETED, S.REJECTED, S.CANCELLED, S.EXPIRED}
    for status in TERMINAL_STATUSES:
        for actor in (CUSTOMER, PROVIDER, STAFF, SYSTEM):
            assert allowed_next(status, actor) == set()


def test_only_system_expires_and_only_provider_rejects():
    assert can_transition(S.REQUESTED, S.EXPIRED, SYSTEM) and not can_transition(S.REQUESTED, S.EXPIRED, CUSTOMER)
    assert can_transition(S.REQUESTED, S.REJECTED, PROVIDER) and not can_transition(S.REQUESTED, S.REJECTED, CUSTOMER)


def test_cancellation_rules():
    assert can_transition(S.REQUESTED, S.CANCELLED, CUSTOMER)
    assert can_transition(S.ARRIVED, S.CANCELLED, PROVIDER)
    assert not can_transition(S.IN_PROGRESS, S.CANCELLED, CUSTOMER)  # work already started
    assert can_transition(S.IN_PROGRESS, S.CANCELLED, STAFF)


def test_every_status_has_a_transition_entry():
    assert set(TRANSITIONS) == set(S)


def test_validate_transition_raises():
    with pytest.raises(InvalidTransition):
        validate_transition(S.COMPLETED, S.CANCELLED, STAFF)
    validate_transition(S.REQUESTED, S.ACCEPTED, PROVIDER)


def test_actor_for_role():
    assert actor_for_role("customer") == CUSTOMER and actor_for_role("support") == STAFF
    assert actor_for_role("finance") is None


# ---- DB-level guards -------------------------------------------------
@pytest.mark.django_db
def test_scheduled_booking_requires_start_time(booking_factory):
    with pytest.raises(IntegrityError), transaction.atomic():
        booking_factory(booking_type="scheduled", scheduled_start=None)


@pytest.mark.django_db
def test_idempotency_key_blocks_duplicate_booking(booking_factory):
    first = booking_factory(idempotency_key="abc")
    with pytest.raises(IntegrityError), transaction.atomic():
        from apps.bookings.models import Booking

        Booking.objects.create(customer=first.customer, service=first.service, address=first.address, idempotency_key="abc")
