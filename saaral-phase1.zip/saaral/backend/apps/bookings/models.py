from decimal import Decimal

from django.conf import settings
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models
from django.db.models import Q

from apps.core.models import BaseModel
from apps.core.utils import generate_booking_reference

from .state import BookingStatus

ZERO = Decimal("0")


def money(**kw):
    return models.DecimalField(max_digits=10, decimal_places=2, default=ZERO, validators=[MinValueValidator(ZERO)], **kw)


class Booking(BaseModel):
    Status = BookingStatus

    class BookingType(models.TextChoices):
        INSTANT = "instant", "Instant"
        SCHEDULED = "scheduled", "Scheduled"

    reference = models.CharField(max_length=16, unique=True, default=generate_booking_reference, editable=False)
    customer = models.ForeignKey("customers.CustomerProfile", on_delete=models.PROTECT, related_name="bookings")
    provider = models.ForeignKey("providers.ProviderProfile", null=True, blank=True, on_delete=models.PROTECT, related_name="bookings")
    service = models.ForeignKey("catalog.Service", on_delete=models.PROTECT, related_name="bookings")
    service_area = models.ForeignKey("catalog.ServiceArea", null=True, blank=True, on_delete=models.PROTECT, related_name="bookings")
    address = models.ForeignKey("customers.Address", on_delete=models.PROTECT, related_name="bookings")
    address_snapshot = models.JSONField(default=dict, help_text="Address as it was at booking time.")
    booking_type = models.CharField(max_length=10, choices=BookingType.choices, default=BookingType.INSTANT)
    status = models.CharField(max_length=15, choices=BookingStatus.choices, default=BookingStatus.REQUESTED, db_index=True)
    scheduled_start = models.DateTimeField(null=True, blank=True)
    is_estimate = models.BooleanField(default=False, help_text="True for inspection-first / starting-from pricing.")

    # Charges shown to the customer BEFORE confirmation, frozen here.
    service_charge = money()
    inspection_charge = money()
    platform_fee = money()
    tax_amount = money()
    discount_amount = money()
    total_amount = money()
    charges_snapshot = models.JSONField(default=dict, blank=True)
    coupon = models.ForeignKey("promotions.Coupon", null=True, blank=True, on_delete=models.SET_NULL, related_name="bookings")

    customer_notes = models.TextField(blank=True)
    idempotency_key = models.CharField(max_length=64, null=True, blank=True, help_text="Client-supplied; blocks duplicate submits.")
    accepted_at = models.DateTimeField(null=True, blank=True)
    started_at = models.DateTimeField(null=True, blank=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    cancelled_at = models.DateTimeField(null=True, blank=True)
    cancelled_by_role = models.CharField(max_length=20, blank=True)
    cancellation_reason = models.TextField(blank=True)

    class Meta:
        indexes = [
            models.Index(fields=["customer", "-created_at"]),
            models.Index(fields=["provider", "status"]),
            models.Index(fields=["status", "created_at"]),
        ]
        constraints = [
            models.UniqueConstraint(
                fields=["customer", "idempotency_key"], condition=Q(idempotency_key__isnull=False),
                name="uniq_booking_idempotency_per_customer",
            ),
            models.CheckConstraint(
                condition=~Q(booking_type="scheduled") | Q(scheduled_start__isnull=False),
                name="scheduled_booking_needs_start",
            ),
        ]

    def participant_user_ids(self):
        ids = {self.customer.user_id}
        if self.provider_id:
            ids.add(self.provider.user_id)
        return ids

    def __str__(self):
        return self.reference


class BookingStatusHistory(BaseModel):
    booking = models.ForeignKey(Booking, on_delete=models.CASCADE, related_name="status_history")
    from_status = models.CharField(max_length=15, blank=True)
    to_status = models.CharField(max_length=15, choices=BookingStatus.choices)
    changed_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    actor = models.CharField(max_length=10, blank=True)
    note = models.CharField(max_length=255, blank=True)

    class Meta:
        ordering = ["created_at"]
        verbose_name_plural = "booking status history"
        indexes = [models.Index(fields=["booking", "created_at"])]


class BookingOTP(BaseModel):
    """Completion OTP. The 4-6 digit code is derived as HMAC(SECRET_KEY, booking_id + nonce), so the
    customer's app can display it and the backend can verify it without storing it (Phase 4)."""

    booking = models.OneToOneField(Booking, on_delete=models.CASCADE, related_name="completion_otp")
    nonce = models.CharField(max_length=32)
    expires_at = models.DateTimeField()
    attempts = models.PositiveSmallIntegerField(default=0)
    verified_at = models.DateTimeField(null=True, blank=True)


class Review(BaseModel):
    class Status(models.TextChoices):
        PUBLISHED = "published", "Published"
        FLAGGED = "flagged", "Flagged for moderation"
        HIDDEN = "hidden", "Hidden"

    booking = models.OneToOneField(Booking, on_delete=models.CASCADE, related_name="review")
    customer = models.ForeignKey("customers.CustomerProfile", on_delete=models.CASCADE, related_name="reviews")
    provider = models.ForeignKey("providers.ProviderProfile", on_delete=models.CASCADE, related_name="reviews")
    rating = models.PositiveSmallIntegerField(validators=[MinValueValidator(1), MaxValueValidator(5)])
    comment = models.TextField(blank=True)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.PUBLISHED, db_index=True)
    moderated_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    moderated_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        constraints = [models.CheckConstraint(condition=Q(rating__gte=1, rating__lte=5), name="review_rating_1_5")]
