from django.contrib import admin

from .models import Complaint


@admin.register(Complaint)
class ComplaintAdmin(admin.ModelAdmin):
    list_display = ("subject", "category", "status", "priority", "raised_by", "assigned_to", "created_at")
    list_filter = ("status", "priority", "category")
