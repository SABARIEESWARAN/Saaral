from decimal import Decimal

from django.conf import settings
from django.core.validators import MinValueValidator
from django.db import models
from django.db.models import F, Q

from apps.core.models import BaseModel

ZERO = Decimal("0")


class Coupon(BaseModel):
    class DiscountType(models.TextChoices):
        PERCENT = "percent", "Percent"
        FLAT = "flat", "Flat amount"

    code = models.CharField(max_length=30, unique=True, help_text="Stored upper-case.")
    description = models.CharField(max_length=255, blank=True)
    discount_type = models.CharField(max_length=8, choices=DiscountType.choices)
    value = models.DecimalField(max_digits=8, decimal_places=2, validators=[MinValueValidator(Decimal("0.01"))])
    max_discount = models.DecimalField(max_digits=8, decimal_places=2, null=True, blank=True, validators=[MinValueValidator(ZERO)])
    min_order_amount = models.DecimalField(max_digits=8, decimal_places=2, default=ZERO, validators=[MinValueValidator(ZERO)])
    valid_from = models.DateTimeField()
    valid_to = models.DateTimeField()
    usage_limit_total = models.PositiveIntegerField(null=True, blank=True)
    usage_limit_per_user = models.PositiveIntegerField(default=1)
    used_count = models.PositiveIntegerField(default=0)
    applicable_categories = models.ManyToManyField("catalog.ServiceCategory", blank=True, related_name="coupons")
    is_active = models.BooleanField(default=True)

    class Meta:
        constraints = [
            models.CheckConstraint(condition=Q(valid_to__gt=F("valid_from")), name="coupon_window_valid"),
            models.CheckConstraint(
                condition=~Q(discount_type="percent") | Q(value__lte=100), name="coupon_percent_max_100"
            ),
        ]

    def save(self, *args, **kwargs):
        self.code = self.code.strip().upper()
        super().save(*args, **kwargs)

    def __str__(self):
        return self.code


class Referral(BaseModel):
    class Status(models.TextChoices):
        PENDING = "pending", "Pending first completed booking"
        REWARDED = "rewarded", "Rewarded"
        EXPIRED = "expired", "Expired"

    referrer = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="referrals_made")
    referred = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="referral_received")
    code_used = models.CharField(max_length=12)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.PENDING, db_index=True)
    reward_amount = models.DecimalField(max_digits=8, decimal_places=2, default=ZERO)
    rewarded_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        constraints = [models.CheckConstraint(condition=~Q(referrer=F("referred")), name="no_self_referral")]
