from django.contrib import admin

from .models import Coupon, Referral


@admin.register(Coupon)
class CouponAdmin(admin.ModelAdmin):
    list_display = ("code", "discount_type", "value", "valid_from", "valid_to", "used_count", "is_active")
    list_filter = ("discount_type", "is_active")
    search_fields = ("code",)
    filter_horizontal = ("applicable_categories",)


@admin.register(Referral)
class ReferralAdmin(admin.ModelAdmin):
    list_display = ("referrer", "referred", "status", "reward_amount")
    list_filter = ("status",)
