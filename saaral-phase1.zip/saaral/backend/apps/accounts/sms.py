"""SMS delivery abstraction. The only bundled backend is a SIMULATION for local development."""
import logging

from django.conf import settings
from django.core.exceptions import ImproperlyConfigured
from django.utils.module_loading import import_string

logger = logging.getLogger(__name__)


class BaseSMSBackend:
    def send(self, phone: str, message: str) -> None:
        raise NotImplementedError


class ConsoleSMSBackend(BaseSMSBackend):
    """SIMULATED: logs the message instead of sending it. Disabled unless AUTH_DEV_MODE=True."""

    def send(self, phone, message):
        if not settings.AUTH_DEV_MODE:
            raise ImproperlyConfigured("ConsoleSMSBackend is a simulation and only runs with AUTH_DEV_MODE=True.")
        logger.warning("[SIMULATED SMS] to=%s message=%s", phone, message)


def get_sms_backend() -> BaseSMSBackend:
    return import_string(settings.SMS_BACKEND)()
