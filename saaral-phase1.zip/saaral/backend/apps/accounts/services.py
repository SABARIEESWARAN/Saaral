import hashlib
import hmac
import logging
import secrets
from datetime import timedelta

from django.conf import settings
from django.db import IntegrityError, transaction
from django.utils import timezone
from rest_framework_simplejwt.tokens import RefreshToken

from apps.core.exceptions import (
    AccountDisabled,
    InvalidCredentials,
    InvalidOTP,
    OTPRateLimited,
    RoleMismatch,
    ServiceUnavailable,
)
from apps.core.roles import SELF_REGISTRATION_ROLES, STAFF_ROLES, Role

from .models import PhoneOTP, User
from .sms import get_sms_backend

logger = logging.getLogger(__name__)
OTP_LENGTH = 6


def _hash_code(phone: str, code: str) -> str:
    key = settings.SECRET_KEY.encode()
    return hmac.new(key, f"otp:{phone}:{code}".encode(), hashlib.sha256).hexdigest()


def _generate_code() -> str:
    if settings.AUTH_DEV_MODE and settings.OTP_DEV_FIXED_CODE:
        return settings.OTP_DEV_FIXED_CODE  # LOCAL DEV ONLY (settings refuse this when DEBUG is false)
    return f"{secrets.randbelow(10 ** OTP_LENGTH):0{OTP_LENGTH}d}"


def request_otp(phone: str) -> None:
    now = timezone.now()
    recent = PhoneOTP.objects.filter(phone=phone, created_at__gte=now - timedelta(hours=1))
    if recent.count() >= settings.OTP_MAX_REQUESTS_PER_HOUR:
        raise OTPRateLimited()
    last = PhoneOTP.objects.filter(phone=phone).order_by("-created_at").first()
    if last and (now - last.created_at).total_seconds() < settings.OTP_RESEND_COOLDOWN_SECONDS:
        raise OTPRateLimited("Please wait a moment before requesting another code.")

    code = _generate_code()
    try:
        with transaction.atomic():
            PhoneOTP.objects.filter(phone=phone, consumed_at__isnull=True).update(consumed_at=now)
            PhoneOTP.objects.create(
                phone=phone,
                code_hash=_hash_code(phone, code),
                expires_at=now + timedelta(seconds=settings.OTP_TTL_SECONDS),
            )
            get_sms_backend().send(phone, f"{code} is your SAARAL verification code. Do not share it with anyone.")
    except OTPRateLimited:
        raise
    except Exception:  # noqa: BLE001 - delivery problems must not leak provider details
        logger.exception("OTP delivery failed")
        raise ServiceUnavailable("Could not send the verification code right now.", code="otp_delivery_unavailable")


def verify_otp(phone: str, code: str) -> None:
    now = timezone.now()
    with transaction.atomic():
        otp = (
            PhoneOTP.objects.select_for_update()
            .filter(phone=phone, consumed_at__isnull=True, expires_at__gt=now)
            .order_by("-created_at")
            .first()
        )
        if otp is None or otp.attempts >= settings.OTP_MAX_ATTEMPTS:
            raise InvalidOTP()
        otp.attempts += 1
        ok = hmac.compare_digest(otp.code_hash, _hash_code(phone, code))
        if ok:
            otp.consumed_at = now
        otp.save(update_fields=["attempts", "consumed_at", "updated_at"])
    if not ok:
        raise InvalidOTP()


def ensure_role_profile(user: User) -> None:
    from apps.customers.models import CustomerProfile
    from apps.providers.models import ProviderProfile

    if user.role == Role.CUSTOMER:
        CustomerProfile.objects.get_or_create(user=user)
    elif user.role == Role.PROVIDER:
        ProviderProfile.objects.get_or_create(user=user, defaults={"display_name": user.full_name})


def login_or_register(*, phone: str, role: str, full_name: str = "", firebase_uid: str | None = None):
    """Return (user, created). Role is fixed at registration; staff can never self-register."""
    if role not in SELF_REGISTRATION_ROLES:
        raise RoleMismatch()
    if firebase_uid and User.objects.filter(firebase_uid=firebase_uid).exclude(phone=phone).exists():
        raise InvalidCredentials()

    user = User.objects.filter(phone=phone).first()
    created = False
    if user is None:
        try:
            with transaction.atomic():
                user = User.objects.create_user(
                    phone=phone,
                    role=role,
                    full_name=full_name.strip(),
                    is_phone_verified=True,
                    firebase_uid=firebase_uid,
                )
            created = True
        except IntegrityError:  # concurrent first login
            user = User.objects.get(phone=phone)

    if not created:
        if not user.is_active:
            raise AccountDisabled()
        if user.role != role:
            raise RoleMismatch()
        changed = []
        if firebase_uid and user.firebase_uid != firebase_uid:
            if user.firebase_uid:
                raise InvalidCredentials()
            user.firebase_uid = firebase_uid
            changed.append("firebase_uid")
        if not user.is_phone_verified:
            user.is_phone_verified = True
            changed.append("is_phone_verified")
        if full_name.strip() and not user.full_name:
            user.full_name = full_name.strip()
            changed.append("full_name")
        if changed:
            user.save(update_fields=changed + ["updated_at"])

    ensure_role_profile(user)
    return user, created


def authenticate_staff(email: str, password: str):
    """Email + password for admin dashboard roles only. Constant-ish time for unknown emails."""
    user = User.objects.filter(email=email.strip().lower()).first()
    if user is None:
        User().set_password(password)  # burn comparable time
        return None
    if not user.check_password(password) or not user.is_active or user.role not in STAFF_ROLES:
        return None
    return user


def issue_tokens(user: User) -> dict:
    refresh = RefreshToken.for_user(user)
    refresh["role"] = user.role  # informational only; permissions always re-read the DB user
    return {"access": str(refresh.access_token), "refresh": str(refresh)}
