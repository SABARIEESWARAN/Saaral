import uuid

from django.contrib.auth.base_user import AbstractBaseUser, BaseUserManager
from django.contrib.auth.models import PermissionsMixin
from django.core.validators import RegexValidator
from django.db import models
from django.db.models import Q
from django.utils import timezone

from apps.core.models import BaseModel
from apps.core.roles import STAFF_ROLES, Role
from apps.core.utils import normalize_phone



class UserManager(BaseUserManager):
    use_in_migrations = True

    def _create(self, phone, password, **extra):
        if not phone:
            raise ValueError("A phone number is required.")
        email = extra.pop("email", None)
        email = self.normalize_email(email).lower() if email else None
        user = self.model(phone=normalize_phone(phone), email=email, **extra)
        if password:
            user.set_password(password)
        else:
            user.set_unusable_password()
        user.save(using=self._db)
        return user

    def create_user(self, phone, password=None, **extra):
        extra.setdefault("is_staff", False)
        extra.setdefault("is_superuser", False)
        return self._create(phone, password, **extra)

    def create_superuser(self, phone, password=None, **extra):
        extra.setdefault("is_staff", True)
        extra.setdefault("is_superuser", True)
        extra.setdefault("role", Role.ADMIN)
        extra.setdefault("is_phone_verified", True)
        if not extra.get("email"):
            raise ValueError("A superuser needs an email address.")
        if not password:
            raise ValueError("A superuser needs a password.")
        return self._create(phone, password, **extra)


class User(AbstractBaseUser, PermissionsMixin):
    """Single identity table. Customers/providers sign in by phone OTP; staff by email + password."""

    class Language(models.TextChoices):
        ENGLISH = "en", "English"
        TAMIL = "ta", "தமிழ்"

    id = models.UUIDField(primary_key=True, default=uuid.uuid4, editable=False)
    phone = models.CharField(
        max_length=16, unique=True, validators=[RegexValidator(r"^\+[1-9]\d{7,14}$", "Use E.164 format.")]
    )
    email = models.EmailField(unique=True, null=True, blank=True)
    full_name = models.CharField(max_length=150, blank=True)
    role = models.CharField(max_length=20, choices=Role.choices, default=Role.CUSTOMER, db_index=True)
    preferred_language = models.CharField(max_length=5, choices=Language.choices, default=Language.ENGLISH)
    firebase_uid = models.CharField(max_length=128, unique=True, null=True, blank=True)
    is_phone_verified = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True)
    is_staff = models.BooleanField(default=False, help_text="Django admin site access only. Not the SAARAL role.")
    date_joined = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)

    objects = UserManager()
    USERNAME_FIELD = "phone"
    REQUIRED_FIELDS = ["email"]

    class Meta:
        constraints = [
            models.CheckConstraint(
                condition=~Q(role__in=sorted(STAFF_ROLES)) | Q(email__isnull=False),
                name="staff_roles_require_email",
            )
        ]

    def save(self, *args, **kwargs):
        self.email = self.email.strip().lower() if self.email else None
        super().save(*args, **kwargs)

    @property
    def is_staff_role(self) -> bool:
        return self.role in STAFF_ROLES

    def __str__(self):
        return f"{self.phone} ({self.role})"


class PhoneOTP(BaseModel):
    """One-time code for phone login. Only an HMAC of the code is stored."""

    phone = models.CharField(max_length=16, db_index=True)
    code_hash = models.CharField(max_length=64)
    expires_at = models.DateTimeField()
    attempts = models.PositiveSmallIntegerField(default=0)
    consumed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        indexes = [models.Index(fields=["phone", "-created_at"])]

    def __str__(self):
        return f"OTP for {self.phone}"
