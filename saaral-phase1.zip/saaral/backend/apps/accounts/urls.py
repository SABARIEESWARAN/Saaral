from django.urls import path

from . import views

app_name = "accounts"

urlpatterns = [
    path("otp/request/", views.OTPRequestView.as_view(), name="otp-request"),
    path("otp/verify/", views.OTPVerifyView.as_view(), name="otp-verify"),
    path("firebase/", views.FirebaseLoginView.as_view(), name="firebase-login"),
    path("admin/login/", views.AdminLoginView.as_view(), name="admin-login"),
    path("token/refresh/", views.ThrottledTokenRefreshView.as_view(), name="token-refresh"),
    path("logout/", views.LogoutView.as_view(), name="logout"),
    path("me/", views.MeView.as_view(), name="me"),
]
