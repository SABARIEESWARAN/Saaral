import pytest

from apps.core.models import AuditLog

pytestmark = pytest.mark.django_db
LOGIN = "/api/v1/auth/admin/login/"


def test_admin_login_success_is_audited(api_client, make_user):
    admin = make_user("admin", email="boss@saaral.test", password="a-Strong-pass-123")
    r = api_client.post(LOGIN, {"email": "Boss@Saaral.test", "password": "a-Strong-pass-123"}, format="json")
    assert r.status_code == 200 and r.data["user"]["role"] == "admin"
    assert AuditLog.objects.filter(action="auth.admin_login", actor=admin).exists()


def test_wrong_password_and_unknown_email_look_identical(api_client, make_user):
    make_user("admin", email="boss@saaral.test", password="a-Strong-pass-123")
    bad_pw = api_client.post(LOGIN, {"email": "boss@saaral.test", "password": "nope"}, format="json")
    unknown = api_client.post(LOGIN, {"email": "ghost@saaral.test", "password": "nope"}, format="json")
    assert bad_pw.status_code == unknown.status_code == 401
    assert bad_pw.data == unknown.data
    assert AuditLog.objects.filter(action="auth.admin_login_failed").count() == 2


def test_customer_cannot_use_admin_login(api_client, make_user):
    make_user("customer", email="cust@saaral.test", password="a-Strong-pass-123")
    r = api_client.post(LOGIN, {"email": "cust@saaral.test", "password": "a-Strong-pass-123"}, format="json")
    assert r.status_code == 401


def test_inactive_staff_cannot_login(api_client, make_user):
    make_user("support", email="s@saaral.test", password="a-Strong-pass-123", is_active=False)
    r = api_client.post(LOGIN, {"email": "s@saaral.test", "password": "a-Strong-pass-123"}, format="json")
    assert r.status_code == 401


def test_me_requires_authentication(api_client):
    assert api_client.get("/api/v1/auth/me/").status_code == 401


def test_me_get_and_patch(api_client, make_user):
    user = make_user("customer")
    api_client.force_authenticate(user)
    assert api_client.get("/api/v1/auth/me/").data["phone"] == user.phone
    r = api_client.patch("/api/v1/auth/me/", {"full_name": "Kavin", "preferred_language": "ta", "role": "admin"}, format="json")
    assert r.status_code == 200
    user.refresh_from_db()
    assert (user.full_name, user.preferred_language, user.role) == ("Kavin", "ta", "customer")  # role is not writable


def test_me_email_uniqueness_and_staff_email_required(api_client, make_user):
    a, b = make_user("customer", email="a@saaral.test"), make_user("customer")
    api_client.force_authenticate(b)
    assert api_client.patch("/api/v1/auth/me/", {"email": "A@saaral.test"}, format="json").status_code == 400
    staff = make_user("support")
    api_client.force_authenticate(staff)
    assert api_client.patch("/api/v1/auth/me/", {"email": ""}, format="json").status_code == 400


def test_logout_blacklists_refresh_token(api_client):
    api_client.post("/api/v1/auth/otp/request/", {"phone": "9876543210"}, format="json")
    tokens = api_client.post(
        "/api/v1/auth/otp/verify/", {"phone": "9876543210", "code": "123456", "role": "customer"}, format="json"
    ).data
    api_client.credentials(HTTP_AUTHORIZATION=f"Bearer {tokens['access']}")
    assert api_client.post("/api/v1/auth/logout/", {"refresh": tokens["refresh"]}, format="json").status_code == 204
    api_client.credentials()
    assert api_client.post("/api/v1/auth/token/refresh/", {"refresh": tokens["refresh"]}, format="json").status_code == 401


def test_cannot_logout_someone_elses_token(api_client, make_user):
    from apps.accounts.services import issue_tokens

    victim_refresh = issue_tokens(make_user("customer"))["refresh"]
    api_client.force_authenticate(make_user("customer"))
    assert api_client.post("/api/v1/auth/logout/", {"refresh": victim_refresh}, format="json").status_code == 400


def test_error_envelope_shape(api_client):
    r = api_client.get("/api/v1/auth/me/")
    assert set(r.data) == {"error"} and {"code", "message"} <= set(r.data["error"])
