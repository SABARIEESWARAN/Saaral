import pytest

from apps.accounts.models import User

pytestmark = pytest.mark.django_db
URL = "/api/v1/auth/firebase/"


def test_firebase_not_configured_returns_503(api_client, settings):
    settings.FIREBASE_CREDENTIALS_FILE = ""
    r = api_client.post(URL, {"id_token": "x", "role": "customer"}, format="json")
    assert r.status_code == 503 and r.data["error"]["code"] == "firebase_not_configured"


def test_firebase_login_creates_user_with_uid(api_client, monkeypatch):
    # Firebase itself is mocked: this tests SAARAL's handling, NOT Firebase verification.
    monkeypatch.setattr("apps.accounts.firebase.verify_phone_id_token", lambda t: ("uid-1", "+919876543210"))
    r = api_client.post(URL, {"id_token": "tok", "role": "provider"}, format="json")
    assert r.status_code == 201
    assert User.objects.get(phone="+919876543210").firebase_uid == "uid-1"


def test_firebase_uid_cannot_be_swapped_on_existing_phone(api_client, monkeypatch, make_user):
    make_user("customer", phone="+919876543210", firebase_uid="uid-1")
    monkeypatch.setattr("apps.accounts.firebase.verify_phone_id_token", lambda t: ("uid-2", "+919876543210"))
    r = api_client.post(URL, {"id_token": "tok", "role": "customer"}, format="json")
    assert r.status_code == 401


def test_firebase_uid_cannot_claim_another_users_phone(api_client, monkeypatch, make_user):
    make_user("customer", phone="+919000000001", firebase_uid="uid-1")
    monkeypatch.setattr("apps.accounts.firebase.verify_phone_id_token", lambda t: ("uid-1", "+919000000002"))
    assert api_client.post(URL, {"id_token": "tok", "role": "customer"}, format="json").status_code == 401
