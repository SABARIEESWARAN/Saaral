from datetime import timedelta

import pytest
from django.utils import timezone

from apps.accounts.models import PhoneOTP, User
from apps.customers.models import CustomerProfile
from apps.providers.models import ProviderProfile

pytestmark = pytest.mark.django_db
REQ, VERIFY = "/api/v1/auth/otp/request/", "/api/v1/auth/otp/verify/"
PHONE = "98765 43210"
E164 = "+919876543210"


def _verify(client, code="123456", role="customer", phone=PHONE, **extra):
    return client.post(VERIFY, {"phone": phone, "code": code, "role": role, **extra}, format="json")


def test_request_otp_stores_only_a_hash(api_client):
    r = api_client.post(REQ, {"phone": PHONE}, format="json")
    assert r.status_code == 202
    otp = PhoneOTP.objects.get(phone=E164)
    assert len(otp.code_hash) == 64 and "123456" not in otp.code_hash


def test_invalid_phone_rejected(api_client):
    r = api_client.post(REQ, {"phone": "12345"}, format="json")
    assert r.status_code == 400 and r.data["error"]["code"] == "validation_error"


def test_resend_cooldown(api_client, settings):
    settings.OTP_RESEND_COOLDOWN_SECONDS = 60
    assert api_client.post(REQ, {"phone": PHONE}, format="json").status_code == 202
    r = api_client.post(REQ, {"phone": PHONE}, format="json")
    assert r.status_code == 429 and r.data["error"]["code"] == "otp_rate_limited"


def test_hourly_request_cap(api_client, settings):
    settings.OTP_MAX_REQUESTS_PER_HOUR = 2
    codes = [api_client.post(REQ, {"phone": PHONE}, format="json").status_code for _ in range(3)]
    assert codes == [202, 202, 429]


def test_new_customer_registers_and_gets_profile(api_client):
    api_client.post(REQ, {"phone": PHONE}, format="json")
    r = _verify(api_client, full_name="Meena")
    assert r.status_code == 201 and r.data["is_new_user"] is True
    assert r.data["user"]["role"] == "customer" and r.data["user"]["full_name"] == "Meena"
    assert {"access", "refresh"} <= set(r.data)
    assert CustomerProfile.objects.filter(user__phone=E164).exists()


def test_new_provider_starts_in_draft(api_client):
    api_client.post(REQ, {"phone": PHONE}, format="json")
    r = _verify(api_client, role="provider")
    assert r.status_code == 201
    assert ProviderProfile.objects.get(user__phone=E164).verification_status == "draft"
    assert r.data["user"]["provider_verification_status"] == "draft"


def test_existing_user_logs_in_with_200(api_client):
    api_client.post(REQ, {"phone": PHONE}, format="json")
    _verify(api_client)
    api_client.post(REQ, {"phone": PHONE}, format="json")
    r = _verify(api_client)
    assert r.status_code == 200 and r.data["is_new_user"] is False
    assert User.objects.filter(phone=E164).count() == 1


def test_wrong_code_then_attempt_limit(api_client, settings):
    settings.OTP_MAX_ATTEMPTS = 3
    api_client.post(REQ, {"phone": PHONE}, format="json")
    for _ in range(3):
        r = _verify(api_client, code="000000")
        assert r.status_code == 400 and r.data["error"]["code"] == "invalid_otp"
    assert _verify(api_client).status_code == 400  # correct code, but attempts exhausted
    assert not User.objects.filter(phone=E164).exists()


def test_code_cannot_be_reused(api_client):
    api_client.post(REQ, {"phone": PHONE}, format="json")
    assert _verify(api_client).status_code == 201
    assert _verify(api_client).status_code == 400


def test_expired_code_rejected(api_client):
    api_client.post(REQ, {"phone": PHONE}, format="json")
    PhoneOTP.objects.update(expires_at=timezone.now() - timedelta(seconds=1))
    assert _verify(api_client).status_code == 400


def test_new_request_invalidates_old_code(api_client):
    api_client.post(REQ, {"phone": PHONE}, format="json")
    first = PhoneOTP.objects.get()
    api_client.post(REQ, {"phone": PHONE}, format="json")
    first.refresh_from_db()
    assert first.consumed_at is not None


def test_staff_roles_cannot_self_register(api_client):
    api_client.post(REQ, {"phone": PHONE}, format="json")
    r = _verify(api_client, role="admin")
    assert r.status_code == 400
    assert not User.objects.filter(phone=E164).exists()


def test_role_mismatch_blocks_login(api_client, make_user):
    make_user("customer", phone=E164)
    api_client.post(REQ, {"phone": PHONE}, format="json")
    r = _verify(api_client, role="provider")
    assert r.status_code == 403 and r.data["error"]["code"] == "role_mismatch"


def test_disabled_account_blocked(api_client, make_user):
    make_user("customer", phone=E164, is_active=False)
    api_client.post(REQ, {"phone": PHONE}, format="json")
    r = _verify(api_client)
    assert r.status_code == 403 and r.data["error"]["code"] == "account_disabled"


def test_sms_failure_is_503_and_leaves_no_code(api_client, settings):
    settings.AUTH_DEV_MODE = False  # ConsoleSMSBackend refuses to run => simulated delivery outage
    r = api_client.post(REQ, {"phone": PHONE}, format="json")
    assert r.status_code == 503 and r.data["error"]["code"] == "otp_delivery_unavailable"
    assert not PhoneOTP.objects.exists()
