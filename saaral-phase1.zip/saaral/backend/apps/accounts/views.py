from django.conf import settings
from drf_spectacular.utils import OpenApiResponse, extend_schema
from rest_framework import serializers
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.exceptions import TokenError
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework_simplejwt.views import TokenRefreshView

from apps.core.audit import log_action
from apps.core.exceptions import InvalidCredentials

from . import firebase, services
from .serializers import (
    AdminLoginSerializer,
    FirebaseLoginSerializer,
    LogoutSerializer,
    OTPRequestSerializer,
    OTPVerifySerializer,
    UserSerializer,
    UserUpdateSerializer,
)


def _auth_response(user, created: bool, request):
    payload = {**services.issue_tokens(user), "is_new_user": created, "user": UserSerializer(user).data}
    return Response(payload, status=201 if created else 200)


class _PublicView(APIView):
    authentication_classes = []  # a stale/invalid token must not break public endpoints
    permission_classes = [AllowAny]


class OTPRequestView(_PublicView):
    throttle_scope = "otp_request"

    @extend_schema(request=OTPRequestSerializer, responses={202: OpenApiResponse(description="Code sent")}, auth=[])
    def post(self, request):
        s = OTPRequestSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        services.request_otp(s.validated_data["phone"])
        return Response({"detail": "Verification code sent.", "expires_in": settings.OTP_TTL_SECONDS}, status=202)


class OTPVerifyView(_PublicView):
    throttle_scope = "otp_verify"

    @extend_schema(request=OTPVerifySerializer, responses={200: OpenApiResponse(description="Tokens"), 201: OpenApiResponse(description="Tokens, new user")}, auth=[])
    def post(self, request):
        s = OTPVerifySerializer(data=request.data)
        s.is_valid(raise_exception=True)
        d = s.validated_data
        services.verify_otp(d["phone"], d["code"])
        user, created = services.login_or_register(phone=d["phone"], role=d["role"], full_name=d["full_name"])
        return _auth_response(user, created, request)


class FirebaseLoginView(_PublicView):
    throttle_scope = "firebase_login"

    @extend_schema(request=FirebaseLoginSerializer, responses={200: OpenApiResponse(description="Tokens")}, auth=[])
    def post(self, request):
        s = FirebaseLoginSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        d = s.validated_data
        uid, phone = firebase.verify_phone_id_token(d["id_token"])
        from apps.core.utils import normalize_phone

        user, created = services.login_or_register(
            phone=normalize_phone(phone), role=d["role"], full_name=d["full_name"], firebase_uid=uid
        )
        return _auth_response(user, created, request)


class AdminLoginView(_PublicView):
    throttle_scope = "admin_login"

    @extend_schema(request=AdminLoginSerializer, responses={200: OpenApiResponse(description="Tokens")}, auth=[])
    def post(self, request):
        s = AdminLoginSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        email = s.validated_data["email"].strip().lower()
        user = services.authenticate_staff(email, s.validated_data["password"])
        if user is None:
            log_action(None, "auth.admin_login_failed", target_type="email", target_id=email, request=request)
            raise InvalidCredentials("Invalid email or password.")
        log_action(user, "auth.admin_login", target=user, request=request)
        return _auth_response(user, False, request)


class ThrottledTokenRefreshView(TokenRefreshView):
    throttle_scope = "token_refresh"


class LogoutView(APIView):
    @extend_schema(request=LogoutSerializer, responses={204: None})
    def post(self, request):
        s = LogoutSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        try:
            token = RefreshToken(s.validated_data["refresh"])
            if str(token.get("user_id")) != str(request.user.id):
                raise TokenError("Token does not belong to this user.")
            token.blacklist()
        except TokenError:
            raise serializers.ValidationError({"refresh": "Invalid or expired token."})
        return Response(status=204)


class MeView(APIView):
    @extend_schema(responses=UserSerializer)
    def get(self, request):
        return Response(UserSerializer(request.user).data)

    @extend_schema(request=UserUpdateSerializer, responses=UserSerializer)
    def patch(self, request):
        s = UserUpdateSerializer(request.user, data=request.data, partial=True)
        s.is_valid(raise_exception=True)
        s.save()
        return Response(UserSerializer(request.user).data)
