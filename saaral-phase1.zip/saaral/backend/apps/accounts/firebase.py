"""Firebase phone-auth token verification.

NOT exercised against real Firebase in this repository's tests (no credentials). Tests monkeypatch
`verify_phone_id_token`. Verify end-to-end with a real Firebase project before relying on it.
"""
import logging

from django.conf import settings

from apps.core.exceptions import InvalidCredentials, ServiceUnavailable

logger = logging.getLogger(__name__)


class FirebaseNotConfigured(ServiceUnavailable):
    default_detail = "Firebase authentication is not configured on this server."
    default_code = "firebase_not_configured"


def _get_app():
    if not settings.FIREBASE_CREDENTIALS_FILE:
        raise FirebaseNotConfigured()
    import firebase_admin
    from firebase_admin import credentials

    try:
        return firebase_admin.get_app()
    except ValueError:
        return firebase_admin.initialize_app(credentials.Certificate(settings.FIREBASE_CREDENTIALS_FILE))


def verify_phone_id_token(id_token: str):
    """Return (firebase_uid, phone_number) for a valid, non-revoked ID token that has a verified phone."""
    app = _get_app()
    from firebase_admin import auth

    try:
        decoded = auth.verify_id_token(id_token, app=app, check_revoked=True)
    except Exception:  # noqa: BLE001 - any verification failure is a 401; details go to logs only
        logger.info("Firebase token rejected", exc_info=True)
        raise InvalidCredentials("Invalid or expired Firebase token.")
    phone = decoded.get("phone_number")
    if not phone:
        raise InvalidCredentials("Firebase token has no verified phone number.")
    return decoded["uid"], phone
