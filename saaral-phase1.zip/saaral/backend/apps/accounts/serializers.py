from django.core.exceptions import ValidationError as DjangoValidationError
from drf_spectacular.utils import extend_schema_field
from rest_framework import serializers

from apps.core.roles import SELF_REGISTRATION_ROLES, STAFF_ROLES
from apps.core.utils import normalize_phone

from .models import User


class PhoneField(serializers.CharField):
    default_error_messages = {"invalid_phone": "Enter a valid phone number."}

    def __init__(self, **kwargs):
        kwargs.setdefault("max_length", 20)
        super().__init__(**kwargs)

    def to_internal_value(self, data):
        value = super().to_internal_value(data)
        try:
            return normalize_phone(value)
        except DjangoValidationError:
            self.fail("invalid_phone")


ROLE_CHOICES = [(r, r) for r in SELF_REGISTRATION_ROLES]


class OTPRequestSerializer(serializers.Serializer):
    phone = PhoneField()


class OTPVerifySerializer(serializers.Serializer):
    phone = PhoneField()
    code = serializers.RegexField(r"^\d{6}$", max_length=6, min_length=6)
    role = serializers.ChoiceField(choices=ROLE_CHOICES)
    full_name = serializers.CharField(max_length=150, required=False, allow_blank=True, default="")


class FirebaseLoginSerializer(serializers.Serializer):
    id_token = serializers.CharField(max_length=4096, trim_whitespace=True)
    role = serializers.ChoiceField(choices=ROLE_CHOICES)
    full_name = serializers.CharField(max_length=150, required=False, allow_blank=True, default="")


class AdminLoginSerializer(serializers.Serializer):
    email = serializers.EmailField(max_length=254)
    password = serializers.CharField(max_length=128, write_only=True, trim_whitespace=False)


class LogoutSerializer(serializers.Serializer):
    refresh = serializers.CharField()


class UserSerializer(serializers.ModelSerializer):
    provider_verification_status = serializers.SerializerMethodField()

    class Meta:
        model = User
        fields = (
            "id", "phone", "email", "full_name", "role", "preferred_language",
            "is_phone_verified", "date_joined", "provider_verification_status",
        )
        read_only_fields = fields

    @extend_schema_field(serializers.CharField(allow_null=True))
    def get_provider_verification_status(self, obj):
        profile = getattr(obj, "provider_profile", None)
        return profile.verification_status if profile else None


class UserUpdateSerializer(serializers.ModelSerializer):
    email = serializers.EmailField(required=False, allow_null=True, allow_blank=True)

    class Meta:
        model = User
        fields = ("full_name", "email", "preferred_language")

    def validate_email(self, value):
        value = (value or "").strip().lower() or None
        if value is None and self.instance.role in STAFF_ROLES:
            raise serializers.ValidationError("Staff accounts must keep an email address.")
        if value and User.objects.filter(email=value).exclude(pk=self.instance.pk).exists():
            raise serializers.ValidationError("This email is already in use.")
        return value
