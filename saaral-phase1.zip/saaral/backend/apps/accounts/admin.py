from django.contrib import admin
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from django.contrib.auth.forms import BaseUserCreationForm, UserChangeForm

from .models import PhoneOTP, User


class SaaralUserCreationForm(BaseUserCreationForm):
    class Meta:
        model = User
        fields = ("phone", "email", "role")


class SaaralUserChangeForm(UserChangeForm):
    class Meta:
        model = User
        fields = "__all__"


@admin.register(User)
class UserAdmin(BaseUserAdmin):
    form = SaaralUserChangeForm
    add_form = SaaralUserCreationForm
    ordering = ("-date_joined",)
    list_display = ("phone", "email", "full_name", "role", "is_active", "date_joined")
    list_filter = ("role", "is_active", "is_staff")
    search_fields = ("phone", "email", "full_name")
    fieldsets = (
        (None, {"fields": ("phone", "password")}),
        ("Personal", {"fields": ("full_name", "email", "preferred_language", "firebase_uid", "is_phone_verified")}),
        ("Access", {"fields": ("role", "is_active", "is_staff", "is_superuser", "groups", "user_permissions")}),
        ("Dates", {"fields": ("last_login", "date_joined")}),
    )
    add_fieldsets = (
        (None, {"classes": ("wide",), "fields": ("phone", "email", "role", "password1", "password2")}),
    )


@admin.register(PhoneOTP)
class PhoneOTPAdmin(admin.ModelAdmin):
    list_display = ("phone", "created_at", "expires_at", "attempts", "consumed_at")
    exclude = ("code_hash",)
    readonly_fields = ("phone", "expires_at", "attempts", "consumed_at")
