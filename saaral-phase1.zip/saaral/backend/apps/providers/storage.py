from django.conf import settings
from django.core.files.storage import FileSystemStorage


def get_private_storage():
    """Private verification-document storage. base_url=None => .url raises, so no accidental public links."""
    return FileSystemStorage(location=settings.PRIVATE_MEDIA_ROOT, base_url=None)
