from django.contrib import admin

from .models import Availability, ProviderDocument, ProviderProfile, ProviderService


@admin.register(ProviderProfile)
class ProviderProfileAdmin(admin.ModelAdmin):
    list_display = ("__str__", "provider_type", "verification_status", "is_online", "rating_avg")
    list_filter = ("verification_status", "provider_type", "is_online")
    search_fields = ("display_name", "business_name", "user__phone")
    filter_horizontal = ("service_areas",)


@admin.register(ProviderDocument)
class ProviderDocumentAdmin(admin.ModelAdmin):
    # `file` is excluded: private storage has no URL, and admin must not become a download path.
    list_display = ("provider", "doc_type", "status", "created_at")
    list_filter = ("doc_type", "status")
    exclude = ("file",)


@admin.register(ProviderService)
class ProviderServiceAdmin(admin.ModelAdmin):
    list_display = ("provider", "service", "price", "is_active")


@admin.register(Availability)
class AvailabilityAdmin(admin.ModelAdmin):
    list_display = ("provider", "weekday", "start_time", "end_time", "is_active")
