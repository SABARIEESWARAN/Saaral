import os
import uuid
from decimal import Decimal

from django.conf import settings
from django.core.validators import MaxValueValidator, MinValueValidator
from django.db import models
from django.db.models import F, Q

from apps.core.models import BaseModel
from apps.catalog.models import PERCENT

from .storage import get_private_storage


class ProviderProfile(BaseModel):
    class ProviderType(models.TextChoices):
        INDEPENDENT = "independent", "Independent professional"
        BUSINESS = "business", "Existing business"

    class Verification(models.TextChoices):
        DRAFT = "draft", "Draft"
        SUBMITTED = "submitted", "Submitted"
        UNDER_REVIEW = "under_review", "Under review"
        APPROVED = "approved", "Approved"
        REJECTED = "rejected", "Rejected"
        SUSPENDED = "suspended", "Suspended"

    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="provider_profile")
    provider_type = models.CharField(max_length=15, choices=ProviderType.choices, default=ProviderType.INDEPENDENT)
    display_name = models.CharField(max_length=150, blank=True)
    business_name = models.CharField(max_length=200, blank=True)
    gstin = models.CharField(max_length=15, blank=True)
    bio = models.TextField(blank=True)
    years_experience = models.PositiveSmallIntegerField(default=0, validators=[MaxValueValidator(70)])
    verification_status = models.CharField(
        max_length=15, choices=Verification.choices, default=Verification.DRAFT, db_index=True
    )
    verification_notes = models.TextField(blank=True)
    verified_at = models.DateTimeField(null=True, blank=True)
    verified_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    is_online = models.BooleanField(default=False, help_text="Provider's own availability switch.")
    rating_avg = models.DecimalField(max_digits=3, decimal_places=2, default=Decimal("0"))
    rating_count = models.PositiveIntegerField(default=0)
    commission_percent = models.DecimalField(
        max_digits=5, decimal_places=2, null=True, blank=True, validators=PERCENT,
        help_text="Optional per-provider override of the commission.",
    )
    service_areas = models.ManyToManyField("catalog.ServiceArea", blank=True, related_name="providers")
    services = models.ManyToManyField("catalog.Service", through="ProviderService", related_name="providers")

    @property
    def owner_user_id(self):
        return self.user_id

    @property
    def is_bookable(self) -> bool:
        return self.verification_status == self.Verification.APPROVED and self.is_online and self.user.is_active

    def __str__(self):
        return self.display_name or self.user.phone


class ProviderService(BaseModel):
    provider = models.ForeignKey(ProviderProfile, on_delete=models.CASCADE, related_name="offered_services")
    service = models.ForeignKey("catalog.Service", on_delete=models.PROTECT, related_name="provider_offerings")
    price = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, validators=[MinValueValidator(Decimal("0"))])
    inspection_charge = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True, validators=[MinValueValidator(Decimal("0"))])
    is_active = models.BooleanField(default=True)

    class Meta:
        constraints = [models.UniqueConstraint(fields=["provider", "service"], name="uniq_provider_service")]

    def __str__(self):
        return f"{self.provider} – {self.service}"


class Availability(BaseModel):
    """Weekly recurring working hours. weekday: 0=Monday … 6=Sunday. No row => not available (never assumed)."""

    provider = models.ForeignKey(ProviderProfile, on_delete=models.CASCADE, related_name="availability_slots")
    weekday = models.PositiveSmallIntegerField(validators=[MaxValueValidator(6)])
    start_time = models.TimeField()
    end_time = models.TimeField()
    is_active = models.BooleanField(default=True)

    class Meta:
        verbose_name_plural = "availability"
        constraints = [
            models.UniqueConstraint(fields=["provider", "weekday", "start_time"], name="uniq_availability_slot"),
            models.CheckConstraint(condition=Q(end_time__gt=F("start_time")), name="availability_end_after_start"),
            models.CheckConstraint(condition=Q(weekday__lte=6), name="availability_weekday_0_6"),
        ]

    def __str__(self):
        return f"{self.provider} d{self.weekday} {self.start_time}-{self.end_time}"


def provider_document_path(instance, filename):
    ext = os.path.splitext(filename)[1].lower()
    return f"provider_docs/{instance.provider_id}/{uuid.uuid4().hex}{ext}"


class ProviderDocument(BaseModel):
    class DocType(models.TextChoices):
        ID_PROOF = "id_proof", "Government ID (masked where possible)"
        PAN = "pan", "PAN"
        QUALIFICATION = "qualification", "Qualification / trade certificate"
        BUSINESS_REGISTRATION = "business_registration", "Business registration"
        GST = "gst", "GST certificate"
        POLICE_VERIFICATION = "police_verification", "Police verification"
        OTHER = "other", "Other"

    class Status(models.TextChoices):
        PENDING = "pending", "Pending review"
        APPROVED = "approved", "Approved"
        REJECTED = "rejected", "Rejected"

    provider = models.ForeignKey(ProviderProfile, on_delete=models.CASCADE, related_name="documents")
    doc_type = models.CharField(max_length=30, choices=DocType.choices)
    file = models.FileField(upload_to=provider_document_path, storage=get_private_storage)
    document_number_last4 = models.CharField(max_length=4, blank=True, help_text="Never store full ID numbers.")
    expires_on = models.DateField(null=True, blank=True)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.PENDING, db_index=True)
    reviewed_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    reviewed_at = models.DateTimeField(null=True, blank=True)
    rejection_reason = models.CharField(max_length=255, blank=True)

    @property
    def owner_user_id(self):
        return self.provider.user_id

    def __str__(self):
        return f"{self.provider} – {self.doc_type}"
