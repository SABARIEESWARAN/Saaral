"""Role-based permission classes. Authorisation always reads the DB user, never JWT claims."""
from rest_framework.permissions import BasePermission

from .roles import STAFF_ROLES, Role

_DENIED = "You do not have permission to perform this action."


def role_permission(name, *roles):
    allowed = frozenset(r.value if isinstance(r, Role) else str(r) for r in roles)

    def has_permission(self, request, view):
        user = request.user
        return bool(user and user.is_authenticated and user.is_active and getattr(user, "role", None) in allowed)

    return type(name, (BasePermission,), {"has_permission": has_permission, "message": _DENIED})


IsCustomer = role_permission("IsCustomer", Role.CUSTOMER)
IsProvider = role_permission("IsProvider", Role.PROVIDER)
IsAdminRole = role_permission("IsAdminRole", Role.ADMIN)
IsFinanceStaff = role_permission("IsFinanceStaff", Role.ADMIN, Role.FINANCE)
IsSupportStaff = role_permission("IsSupportStaff", Role.ADMIN, Role.SUPPORT)
IsStaffRole = role_permission("IsStaffRole", *STAFF_ROLES)


class IsOwnerOrStaff(BasePermission):
    """Object-level: the owner (`obj.owner_user_id`) or admin/support staff. Combine with a view-level role class."""

    message = _DENIED

    def has_object_permission(self, request, view, obj):
        user = request.user
        if getattr(user, "role", None) in (Role.ADMIN.value, Role.SUPPORT.value):
            return True
        return getattr(obj, "owner_user_id", None) == user.id
