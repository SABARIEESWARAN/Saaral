from .models import AuditLog


def log_action(actor, action, *, target=None, target_type="", target_id="", changes=None, request=None):
    """Write an audit entry. Never pass secrets or full documents in `changes`."""
    if target is not None:
        target_type = target_type or target.__class__.__name__
        target_id = target_id or str(getattr(target, "pk", ""))
    meta = getattr(request, "META", {}) if request is not None else {}
    return AuditLog.objects.create(
        actor=actor if getattr(actor, "pk", None) else None,
        actor_role=getattr(actor, "role", "") or "",
        action=action,
        target_type=target_type,
        target_id=str(target_id)[:64],
        changes=changes or {},
        ip_address=meta.get("REMOTE_ADDR") or None,
        user_agent=meta.get("HTTP_USER_AGENT", "")[:255],
    )
