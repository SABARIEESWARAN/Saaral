"""Role definitions shared by every module (kept free of model imports)."""
from django.db import models


class Role(models.TextChoices):
    CUSTOMER = "customer", "Customer"
    PROVIDER = "provider", "Service provider"
    ADMIN = "admin", "Administrator"
    SUPPORT = "support", "Support agent"
    FINANCE = "finance", "Finance"


STAFF_ROLES = frozenset({Role.ADMIN.value, Role.SUPPORT.value, Role.FINANCE.value})
SELF_REGISTRATION_ROLES = (Role.CUSTOMER.value, Role.PROVIDER.value)
