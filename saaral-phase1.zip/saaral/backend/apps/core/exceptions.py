import logging

from rest_framework import exceptions
from rest_framework.response import Response
from rest_framework.views import exception_handler as drf_exception_handler

logger = logging.getLogger(__name__)


class InvalidOTP(exceptions.APIException):
    status_code = 400
    default_detail = "Invalid or expired verification code."
    default_code = "invalid_otp"


class OTPRateLimited(exceptions.APIException):
    status_code = 429
    default_detail = "Too many verification requests. Please try again later."
    default_code = "otp_rate_limited"


class InvalidCredentials(exceptions.APIException):
    status_code = 401
    default_detail = "Invalid credentials."
    default_code = "invalid_credentials"


class AccountDisabled(exceptions.APIException):
    status_code = 403
    default_detail = "This account has been disabled."
    default_code = "account_disabled"


class RoleMismatch(exceptions.APIException):
    status_code = 403
    default_detail = "This phone number is registered for a different type of account."
    default_code = "role_mismatch"


class ServiceUnavailable(exceptions.APIException):
    status_code = 503
    default_detail = "Service temporarily unavailable."
    default_code = "service_unavailable"


def custom_exception_handler(exc, context):
    """Uniform error body: {"error": {"code", "message", "details"?}}."""
    response = drf_exception_handler(exc, context)
    if response is None:
        view = context.get("view")
        logger.exception("Unhandled exception in %s", view.__class__.__name__ if view else "?")
        return Response(
            {"error": {"code": "server_error", "message": "Something went wrong. Please try again."}}, status=500
        )

    details = None
    if isinstance(exc, exceptions.ValidationError):
        code, message, details = "validation_error", "Invalid input.", response.data
    else:
        codes = exc.get_codes() if isinstance(exc, exceptions.APIException) else None
        code = codes if isinstance(codes, str) else getattr(exc, "default_code", "error")
        data = response.data
        message = str(data.get("detail", "")) if isinstance(data, dict) else ""
        message = message or str(exc)
    body = {"error": {"code": code, "message": message}}
    if details is not None:
        body["error"]["details"] = details
    response.data = body
    return response
