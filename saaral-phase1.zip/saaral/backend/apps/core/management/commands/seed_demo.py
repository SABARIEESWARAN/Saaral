"""LOCAL-ONLY demo data. Idempotent. Refuses to run unless DEBUG is true (or --force).

All prices, PIN codes and coordinates below are PLACEHOLDERS for development. Tamil copy needs review
by a native speaker. Real pricing/zones are configured by admins.
"""
import os
import secrets
from datetime import time
from decimal import Decimal

from django.conf import settings
from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from apps.accounts.models import User
from apps.catalog.models import Service, ServiceArea, ServiceCategory
from apps.core.models import PlatformSetting
from apps.core.platform import COMMISSION_SETTING_KEY
from apps.core.roles import Role
from apps.customers.models import Address, CustomerProfile
from apps.providers.models import Availability, ProviderProfile, ProviderService

F, S, I = "fixed", "starting_from", "inspection_first"

CATEGORIES = [
    # slug, name_en, name_ta, icon
    ("plumbing", "Plumbing", "பிளம்பிங்", "plumbing"),
    ("electrical", "Electrical repairs", "மின் பழுதுபார்ப்பு", "electrical"),
    ("ac-service", "AC servicing & repair", "ஏசி சர்வீஸ் & பழுது", "ac"),
    ("washing-machine", "Washing machine repair", "வாஷிங் மெஷின் பழுது", "washing_machine"),
    ("refrigerator", "Refrigerator repair", "ஃப்ரிட்ஜ் பழுது", "fridge"),
    ("laundry", "Laundry & ironing", "சலவை & இஸ்திரி", "laundry"),
]

SERVICES = [
    # category, slug, name_en, name_ta, pricing, unit, base_price, inspection_charge, minutes
    ("plumbing", "tap-leak-repair", "Tap / leak repair", "குழாய் / கசிவு பழுது", S, "visit", "199", "0", 60),
    ("plumbing", "drain-blockage", "Drain blockage clearing", "அடைப்பு நீக்கம்", I, "visit", None, "149", 90),
    ("electrical", "fan-light-fitting", "Fan / light fitting", "ஃபேன் / விளக்கு பொருத்துதல்", F, "visit", "249", "0", 45),
    ("electrical", "wiring-fault", "Wiring fault diagnosis", "வயரிங் கோளாறு ஆய்வு", I, "visit", None, "199", 90),
    ("ac-service", "ac-general-service", "AC general service", "ஏசி பொது சர்வீஸ்", F, "visit", "599", "0", 60),
    ("ac-service", "ac-repair", "AC repair", "ஏசி பழுது", I, "visit", None, "249", 90),
    ("washing-machine", "wm-repair", "Washing machine repair", "வாஷிங் மெஷின் பழுது", I, "visit", None, "249", 90),
    ("washing-machine", "wm-deep-clean", "Washing machine deep cleaning", "வாஷிங் மெஷின் சுத்தம்", F, "visit", "499", "0", 60),
    ("refrigerator", "fridge-repair", "Refrigerator repair", "ஃப்ரிட்ஜ் பழுது", I, "visit", None, "249", 90),
    ("refrigerator", "fridge-deep-clean", "Refrigerator deep cleaning", "ஃப்ரிட்ஜ் சுத்தம்", F, "visit", "399", "0", 60),
    ("laundry", "wash-and-iron", "Wash & iron", "துவைத்து இஸ்திரி", F, "kg", "79", "0", 0),
    ("laundry", "ironing", "Ironing only", "இஸ்திரி மட்டும்", F, "item", "12", "0", 0),
]

AREAS = [  # slug, name, pincode, lat, lng, radius_km  (approximate – verify with local operations)
    ("rs-puram", "RS Puram", "641002", "11.0070", "76.9500", "3.0"),
    ("gandhipuram", "Gandhipuram", "641012", "11.0183", "76.9725", "3.0"),
    ("race-course", "Race Course", "641018", "10.9988", "76.9731", "3.0"),
    ("saibaba-colony", "Saibaba Colony", "641011", "11.0262", "76.9435", "3.0"),
    ("peelamedu", "Peelamedu", "641004", "11.0243", "77.0027", "3.5"),
    ("singanallur", "Singanallur", "641005", "10.9990", "77.0290", "3.5"),
]

DEMO_CUSTOMER_PHONE = "+919999900001"
DEMO_PROVIDER_PHONE = "+919999900002"
DEMO_ADMIN_PHONE = "+919999900000"
DEMO_ADMIN_EMAIL = "admin@saaral.local"


class Command(BaseCommand):
    help = "Load LOCAL-ONLY demo catalog, zones and demo accounts."

    def add_arguments(self, parser):
        parser.add_argument("--force", action="store_true", help="Allow running when DEBUG is false (never in production).")

    def handle(self, *args, **opts):
        if not settings.DEBUG and not opts["force"]:
            raise CommandError("seed_demo creates demo accounts and is for local use only (DJANGO_DEBUG=True).")
        with transaction.atomic():
            categories = self._categories()
            services = self._services(categories)
            areas = self._areas()
            PlatformSetting.objects.get_or_create(
                key=COMMISSION_SETTING_KEY,
                defaults={"value": settings.DEFAULT_COMMISSION_PERCENT, "description": "Platform default commission (%)"},
            )
            admin_pw = self._admin()
            self._customer()
            self._provider(services, areas)
        self.stdout.write(self.style.SUCCESS("Demo data ready (local testing only)."))
        self.stdout.write(f"  customer phone : {DEMO_CUSTOMER_PHONE}   provider phone: {DEMO_PROVIDER_PHONE}")
        self.stdout.write(f"  admin login    : {DEMO_ADMIN_EMAIL}")
        if admin_pw:
            self.stdout.write(f"  admin password : {admin_pw}   (shown once – store it locally)")
        if settings.AUTH_DEV_MODE and settings.OTP_DEV_FIXED_CODE:
            self.stdout.write(f"  dev OTP code   : {settings.OTP_DEV_FIXED_CODE}   (AUTH_DEV_MODE, simulated SMS)")

    def _categories(self):
        out = {}
        for order, (slug, en, ta, icon) in enumerate(CATEGORIES):
            out[slug], _ = ServiceCategory.objects.update_or_create(
                slug=slug, defaults={"name_en": en, "name_ta": ta, "icon": icon, "sort_order": order, "is_active": True}
            )
        return out

    def _services(self, categories):
        out = {}
        for cat, slug, en, ta, pricing, unit, price, insp, minutes in SERVICES:
            out[slug], _ = Service.objects.update_or_create(
                category=categories[cat], slug=slug,
                defaults={
                    "name_en": en, "name_ta": ta, "pricing_type": pricing, "unit": unit,
                    "base_price": Decimal(price) if price else None,
                    "inspection_charge": Decimal(insp), "estimated_duration_minutes": minutes, "is_active": True,
                },
            )
        return out

    def _areas(self):
        out = {}
        for slug, name, pin, lat, lng, radius in AREAS:
            out[slug], _ = ServiceArea.objects.update_or_create(
                slug=slug,
                defaults={
                    "name": name, "pincodes": [pin], "center_latitude": Decimal(lat), "center_longitude": Decimal(lng),
                    "radius_km": Decimal(radius), "is_serviceable": True, "is_active": True,
                },
            )
        return out

    def _admin(self):
        if User.objects.filter(email=DEMO_ADMIN_EMAIL).exists():
            return None
        password = os.environ.get("DEMO_ADMIN_PASSWORD") or secrets.token_urlsafe(14)
        User.objects.create_superuser(
            phone=DEMO_ADMIN_PHONE, email=DEMO_ADMIN_EMAIL, password=password, full_name="Demo Admin"
        )
        return password

    def _user(self, phone, role, name):
        user = User.objects.filter(phone=phone).first()
        return user or User.objects.create_user(phone=phone, role=role, full_name=name, is_phone_verified=True)

    def _customer(self):
        user = self._user(DEMO_CUSTOMER_PHONE, Role.CUSTOMER, "Demo Customer")
        profile, _ = CustomerProfile.objects.get_or_create(user=user)
        Address.objects.update_or_create(
            customer=profile, label="home",
            defaults={
                "contact_name": "Demo Customer", "contact_phone": DEMO_CUSTOMER_PHONE, "line1": "12, Sample Street",
                "locality": "RS Puram", "pincode": "641002", "latitude": Decimal("11.0075"), "longitude": Decimal("76.9505"),
                "is_default": True, "is_active": True,
            },
        )

    def _provider(self, services, areas):
        user = self._user(DEMO_PROVIDER_PHONE, Role.PROVIDER, "Demo Provider")
        profile, _ = ProviderProfile.objects.update_or_create(
            user=user,
            defaults={
                "display_name": "Demo Provider (Plumbing & Electrical)", "years_experience": 5,
                "verification_status": ProviderProfile.Verification.APPROVED, "is_online": True,
            },
        )
        profile.service_areas.set([areas["rs-puram"], areas["gandhipuram"], areas["race-course"]])
        for slug in ("tap-leak-repair", "drain-blockage", "fan-light-fitting", "wiring-fault"):
            ProviderService.objects.get_or_create(provider=profile, service=services[slug])
        for weekday in range(0, 6):  # Mon–Sat
            Availability.objects.get_or_create(
                provider=profile, weekday=weekday, start_time=time(9, 0), defaults={"end_time": time(18, 0)}
            )
