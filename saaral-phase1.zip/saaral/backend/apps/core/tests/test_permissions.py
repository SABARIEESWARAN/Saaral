from types import SimpleNamespace

import pytest
from rest_framework.response import Response
from rest_framework.test import APIRequestFactory, force_authenticate
from rest_framework.views import APIView

from apps.core.permissions import IsAdminRole, IsCustomer, IsFinanceStaff, IsOwnerOrStaff, IsProvider, IsStaffRole

pytestmark = pytest.mark.django_db


def _call(permission, user):
    class V(APIView):
        permission_classes = [permission]

        def get(self, request):
            return Response({"ok": True})

    request = APIRequestFactory().get("/x")
    if user is not None:
        force_authenticate(request, user=user)
    return V.as_view()(request).status_code


@pytest.mark.parametrize(
    "permission,allowed",
    [
        (IsCustomer, {"customer"}),
        (IsProvider, {"provider"}),
        (IsAdminRole, {"admin"}),
        (IsFinanceStaff, {"admin", "finance"}),
        (IsStaffRole, {"admin", "support", "finance"}),
    ],
)
def test_role_matrix(permission, allowed, make_user):
    for role in ("customer", "provider", "admin", "support", "finance"):
        expected = 200 if role in allowed else 403
        assert _call(permission, make_user(role)) == expected, (permission.__name__, role)


def test_anonymous_is_rejected():
    assert _call(IsCustomer, None) in (401, 403)


def test_inactive_user_is_rejected(make_user):
    assert _call(IsCustomer, make_user("customer", is_active=False)) == 403


def test_owner_or_staff_object_permission(make_user):
    owner, other, admin, support, finance = (make_user(r) for r in ("customer", "customer", "admin", "support", "finance"))
    obj = SimpleNamespace(owner_user_id=owner.id)
    perm = IsOwnerOrStaff()
    has = lambda u: perm.has_object_permission(SimpleNamespace(user=u), None, obj)  # noqa: E731
    assert has(owner) and has(admin) and has(support)
    assert not has(other) and not has(finance)
