from io import StringIO

import pytest
from django.core.management import call_command
from django.core.management.base import CommandError

from apps.accounts.models import User
from apps.catalog.models import Service, ServiceArea, ServiceCategory
from apps.providers.models import ProviderProfile

pytestmark = pytest.mark.django_db


def test_seed_demo_loads_catalog_and_is_idempotent():
    for _ in range(2):
        call_command("seed_demo", force=True, stdout=StringIO())
    assert ServiceCategory.objects.count() == 6
    assert all(c.services.exists() for c in ServiceCategory.objects.all())
    assert Service.objects.filter(pricing_type="inspection_first", base_price__isnull=True).exists()
    assert ServiceArea.objects.filter(city="Coimbatore").count() == 6
    assert User.objects.filter(role="admin").count() == 1
    assert ProviderProfile.objects.get(user__phone="+919999900002").is_bookable


def test_seed_demo_refuses_without_debug(settings):
    settings.DEBUG = False
    with pytest.raises(CommandError):
        call_command("seed_demo", stdout=StringIO())
