from decimal import Decimal

import pytest
from django.core.exceptions import ImproperlyConfigured

from apps.catalog.models import ServiceCategory
from apps.core.audit import log_action
from apps.core.models import AuditLog, PlatformSetting
from apps.core.platform import COMMISSION_SETTING_KEY, effective_commission_percent
from apps.core.roles import Role

pytestmark = pytest.mark.django_db


def test_commission_falls_back_to_env_default(settings):
    settings.DEFAULT_COMMISSION_PERCENT = "15"
    assert effective_commission_percent() == Decimal("15")


def test_commission_precedence_provider_over_category_over_platform(make_user):
    PlatformSetting.objects.create(key=COMMISSION_SETTING_KEY, value=12)
    category = ServiceCategory.objects.create(slug="c", name_en="C", commission_percent=Decimal("10"))
    provider = make_user(Role.PROVIDER).provider_profile
    assert effective_commission_percent() == Decimal("12")
    assert effective_commission_percent(category=category) == Decimal("10")
    provider.commission_percent = Decimal("8.5")
    assert effective_commission_percent(provider=provider, category=category) == Decimal("8.5")


def test_commission_rejects_out_of_range():
    PlatformSetting.objects.create(key=COMMISSION_SETTING_KEY, value=150)
    with pytest.raises(ImproperlyConfigured):
        effective_commission_percent()


def test_audit_log_is_append_only(make_user):
    entry = log_action(make_user(Role.ADMIN), "test.action", target_type="X", target_id="1")
    assert AuditLog.objects.count() == 1
    entry.action = "tampered"
    with pytest.raises(PermissionError):
        entry.save()
    with pytest.raises(PermissionError):
        entry.delete()
    with pytest.raises(PermissionError):
        AuditLog.objects.all().update(action="x")
    with pytest.raises(PermissionError):
        AuditLog.objects.all().delete()
