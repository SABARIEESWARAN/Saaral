import pytest
from django.core.exceptions import ValidationError

from apps.core.utils import generate_booking_reference, haversine_km, normalize_phone


@pytest.mark.parametrize(
    "raw,expected",
    [
        ("9876543210", "+919876543210"),
        ("98765 43210", "+919876543210"),
        ("+91 98765-43210", "+919876543210"),
        ("919876543210", "+919876543210"),
        ("09876543210", "+919876543210"),
        ("+14155552671", "+14155552671"),
    ],
)
def test_normalize_phone_valid(raw, expected):
    assert normalize_phone(raw) == expected


@pytest.mark.parametrize("raw", ["", "12345", "5876543210", "abcdefghij", "+0123456789", None])
def test_normalize_phone_invalid(raw):
    with pytest.raises(ValidationError):
        normalize_phone(raw)


def test_haversine_known_distances():
    assert haversine_km(11.0, 76.9, 11.0, 76.9) == 0
    assert abs(haversine_km(0, 0, 1, 0) - 111.195) < 0.01
    assert 2.6 < haversine_km(11.0070, 76.9500, 11.0183, 76.9725) < 2.9  # RS Puram -> Gandhipuram


def test_booking_reference_format():
    ref = generate_booking_reference()
    assert ref.startswith("SAR-") and len(ref) == 12
