from django.db import connection
from drf_spectacular.utils import extend_schema
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from rest_framework.views import APIView


class _Public(APIView):
    authentication_classes = []
    permission_classes = [AllowAny]
    throttle_classes = []


@extend_schema(exclude=True)
class HealthView(_Public):
    def get(self, request):
        return Response({"status": "ok"})


@extend_schema(exclude=True)
class ReadinessView(_Public):
    def get(self, request):
        try:
            connection.ensure_connection()
        except Exception:  # noqa: BLE001 - report, never leak details
            return Response({"status": "unavailable"}, status=503)
        return Response({"status": "ready"})
