import math
import re
import secrets
from decimal import ROUND_HALF_UP, Decimal

from django.core.exceptions import ValidationError

SAFE_ALPHABET = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"  # no 0/O/1/I/L
_E164 = re.compile(r"^\+[1-9]\d{7,14}$")
_IN_MOBILE = re.compile(r"^[6-9]\d{9}$")


def normalize_phone(raw) -> str:
    """Return an E.164 phone number. Bare Indian mobiles (10 digits, 6-9 prefix) get +91."""
    if raw is None:
        raise ValidationError("Phone number is required.")
    cleaned = re.sub(r"[\s\-().]", "", str(raw))
    if cleaned.startswith("00"):
        cleaned = "+" + cleaned[2:]
    if _IN_MOBILE.match(cleaned):
        cleaned = "+91" + cleaned
    elif cleaned.startswith("0") and _IN_MOBILE.match(cleaned[1:]):
        cleaned = "+91" + cleaned[1:]
    elif re.match(r"^91[6-9]\d{9}$", cleaned):
        cleaned = "+" + cleaned
    if not _E164.match(cleaned):
        raise ValidationError("Enter a valid phone number.")
    return cleaned


def random_code(length: int, alphabet: str = SAFE_ALPHABET) -> str:
    return "".join(secrets.choice(alphabet) for _ in range(length))


def generate_referral_code() -> str:
    return random_code(8)


def generate_booking_reference() -> str:
    return "SAR-" + random_code(8)


def quantize_money(value) -> Decimal:
    return Decimal(value).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def haversine_km(lat1, lng1, lat2, lng2) -> float:
    """Great-circle distance. Used until PostGIS distance queries replace it."""
    r = 6371.0
    p1, p2 = math.radians(float(lat1)), math.radians(float(lat2))
    dphi = p2 - p1
    dlmb = math.radians(float(lng2) - float(lng1))
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dlmb / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))
