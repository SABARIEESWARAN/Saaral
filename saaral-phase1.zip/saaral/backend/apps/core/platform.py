"""Configurable business rules. Commission is NEVER hard-coded in business logic."""
from decimal import Decimal, InvalidOperation

from django.conf import settings
from django.core.exceptions import ImproperlyConfigured

COMMISSION_SETTING_KEY = "commission.default_percent"


def _to_percent(value) -> Decimal:
    try:
        pct = Decimal(str(value))
    except (InvalidOperation, ValueError):
        raise ImproperlyConfigured(f"Invalid commission percent: {value!r}")
    if not (Decimal("0") <= pct <= Decimal("100")):
        raise ImproperlyConfigured(f"Commission percent out of range: {pct}")
    return pct


def default_commission_percent() -> Decimal:
    from .models import PlatformSetting

    row = PlatformSetting.objects.filter(key=COMMISSION_SETTING_KEY).first()
    return _to_percent(row.value if row else settings.DEFAULT_COMMISSION_PERCENT)


def effective_commission_percent(*, provider=None, category=None) -> Decimal:
    """Precedence: provider override > category override > platform setting > env fallback."""
    for obj in (provider, category):
        pct = getattr(obj, "commission_percent", None)
        if pct is not None:
            return _to_percent(pct)
    return default_commission_percent()
