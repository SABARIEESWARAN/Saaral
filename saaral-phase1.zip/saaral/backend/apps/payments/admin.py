from django.contrib import admin

from .models import Commission, Payment, ProviderPayout, Refund


@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ("booking", "method", "gateway", "status", "amount", "paid_at")
    list_filter = ("status", "gateway", "method")


@admin.register(Refund)
class RefundAdmin(admin.ModelAdmin):
    list_display = ("booking", "amount", "status", "created_at")
    list_filter = ("status",)


@admin.register(ProviderPayout)
class ProviderPayoutAdmin(admin.ModelAdmin):
    list_display = ("provider", "period_start", "period_end", "total_amount", "status")
    list_filter = ("status",)


@admin.register(Commission)
class CommissionAdmin(admin.ModelAdmin):
    list_display = ("booking", "provider", "rate_percent", "commission_amount", "provider_payable", "status")
    list_filter = ("status",)
