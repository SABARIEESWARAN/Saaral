from decimal import Decimal

from django.conf import settings
from django.core.validators import MinValueValidator
from django.db import models
from django.db.models import F, Q

from apps.catalog.models import PERCENT
from apps.core.models import BaseModel

ZERO = Decimal("0")


def money(**kw):
    return models.DecimalField(max_digits=10, decimal_places=2, validators=[MinValueValidator(ZERO)], **kw)


class Payment(BaseModel):
    class Method(models.TextChoices):
        UPI = "upi", "UPI"
        CARD = "card", "Card"
        NETBANKING = "netbanking", "Net banking"
        CASH = "cash", "Cash on service"

    class Status(models.TextChoices):
        PENDING = "pending", "Pending"
        CAPTURED = "captured", "Captured / paid"
        FAILED = "failed", "Failed"
        PARTIALLY_REFUNDED = "partially_refunded", "Partially refunded"
        REFUNDED = "refunded", "Refunded"

    class Gateway(models.TextChoices):
        SIMULATED = "simulated", "Simulated (testing only)"
        RAZORPAY = "razorpay", "Razorpay"
        CASH = "cash", "Cash"

    booking = models.ForeignKey("bookings.Booking", on_delete=models.PROTECT, related_name="payments")
    method = models.CharField(max_length=12, choices=Method.choices)
    gateway = models.CharField(max_length=12, choices=Gateway.choices, default=Gateway.SIMULATED)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.PENDING, db_index=True)
    amount = money()
    currency = models.CharField(max_length=3, default="INR")
    gateway_order_id = models.CharField(max_length=100, null=True, blank=True)
    gateway_payment_id = models.CharField(max_length=100, null=True, blank=True)
    idempotency_key = models.CharField(max_length=64, unique=True, null=True, blank=True)
    paid_at = models.DateTimeField(null=True, blank=True)
    failure_reason = models.CharField(max_length=255, blank=True)

    class Meta:
        indexes = [models.Index(fields=["booking", "status"])]
        constraints = [
            # DB-level guard against double payment of one booking.
            models.UniqueConstraint(
                fields=["booking"], condition=Q(status__in=["captured", "partially_refunded"]),
                name="one_captured_payment_per_booking",
            ),
            # The same gateway event can never be recorded twice.
            models.UniqueConstraint(
                fields=["gateway", "gateway_payment_id"], condition=Q(gateway_payment_id__isnull=False),
                name="uniq_gateway_payment_id",
            ),
            models.CheckConstraint(condition=Q(amount__gt=0), name="payment_amount_positive"),
        ]


class Refund(BaseModel):
    class Status(models.TextChoices):
        REQUESTED = "requested", "Requested"
        APPROVED = "approved", "Approved"
        REJECTED = "rejected", "Rejected"
        PROCESSED = "processed", "Processed"
        FAILED = "failed", "Failed"

    payment = models.ForeignKey(Payment, on_delete=models.PROTECT, related_name="refunds")
    booking = models.ForeignKey("bookings.Booking", on_delete=models.PROTECT, related_name="refunds")
    amount = money()
    reason = models.TextField(blank=True)
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.REQUESTED, db_index=True)
    requested_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    reviewed_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    reviewed_at = models.DateTimeField(null=True, blank=True)
    gateway_refund_id = models.CharField(max_length=100, null=True, blank=True, unique=True)
    processed_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        constraints = [models.CheckConstraint(condition=Q(amount__gt=0), name="refund_amount_positive")]


class ProviderPayout(BaseModel):
    class Status(models.TextChoices):
        PENDING = "pending", "Pending"
        PROCESSING = "processing", "Processing"
        PAID = "paid", "Paid"
        FAILED = "failed", "Failed"

    provider = models.ForeignKey("providers.ProviderProfile", on_delete=models.PROTECT, related_name="payouts")
    period_start = models.DateField()
    period_end = models.DateField()
    total_amount = money()
    status = models.CharField(max_length=12, choices=Status.choices, default=Status.PENDING, db_index=True)
    reference = models.CharField(max_length=100, blank=True)
    paid_at = models.DateTimeField(null=True, blank=True)
    created_by = models.ForeignKey(settings.AUTH_USER_MODEL, null=True, blank=True, on_delete=models.SET_NULL, related_name="+")
    notes = models.TextField(blank=True)

    class Meta:
        constraints = [models.CheckConstraint(condition=Q(period_end__gte=F("period_start")), name="payout_period_valid")]


class Commission(BaseModel):
    """Frozen per-booking split. rate_percent is copied from configuration at completion time."""

    class Status(models.TextChoices):
        PENDING = "pending", "Pending settlement"
        SETTLED = "settled", "Settled"
        REVERSED = "reversed", "Reversed"

    booking = models.OneToOneField("bookings.Booking", on_delete=models.PROTECT, related_name="commission")
    provider = models.ForeignKey("providers.ProviderProfile", on_delete=models.PROTECT, related_name="commissions")
    rate_percent = models.DecimalField(max_digits=5, decimal_places=2, validators=PERCENT)
    gross_amount = money()
    commission_amount = money()
    provider_payable = money()
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.PENDING, db_index=True)
    payout = models.ForeignKey(ProviderPayout, null=True, blank=True, on_delete=models.SET_NULL, related_name="commissions")
