from decimal import Decimal

import pytest
from django.db import IntegrityError, transaction

from apps.payments.models import Payment

pytestmark = pytest.mark.django_db


def _pay(booking, **kw):
    defaults = dict(booking=booking, method="upi", amount=Decimal("100"), gateway="simulated")
    defaults.update(kw)
    return Payment.objects.create(**defaults)


def test_only_one_captured_payment_per_booking(booking_factory):
    booking = booking_factory()
    _pay(booking, status="failed")
    _pay(booking, status="captured")
    with pytest.raises(IntegrityError), transaction.atomic():
        _pay(booking, status="captured")


def test_gateway_payment_id_cannot_repeat(booking_factory):
    b1, b2 = booking_factory(), booking_factory()
    _pay(b1, gateway_payment_id="pay_1")
    with pytest.raises(IntegrityError), transaction.atomic():
        _pay(b2, gateway_payment_id="pay_1")


def test_payment_amount_must_be_positive(booking_factory):
    with pytest.raises(IntegrityError), transaction.atomic():
        _pay(booking_factory(), amount=Decimal("0"))
