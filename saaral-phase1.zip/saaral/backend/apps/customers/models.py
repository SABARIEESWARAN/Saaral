from django.conf import settings
from django.core.validators import MaxValueValidator, MinValueValidator, RegexValidator
from django.db import models
from django.db.models import Q

from apps.core.models import BaseModel
from apps.core.utils import generate_referral_code

PINCODE_VALIDATOR = RegexValidator(r"^[1-9][0-9]{5}$", "Enter a valid 6-digit PIN code.")


def latitude_field():
    return models.DecimalField(
        max_digits=9, decimal_places=6, null=True, blank=True,
        validators=[MinValueValidator(-90), MaxValueValidator(90)],
    )


def longitude_field():
    return models.DecimalField(
        max_digits=9, decimal_places=6, null=True, blank=True,
        validators=[MinValueValidator(-180), MaxValueValidator(180)],
    )


class CustomerProfile(BaseModel):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="customer_profile")
    referral_code = models.CharField(max_length=12, unique=True, default=generate_referral_code)
    marketing_opt_in = models.BooleanField(default=False)

    @property
    def owner_user_id(self):
        return self.user_id

    def __str__(self):
        return f"Customer {self.user.phone}"


class Address(BaseModel):
    class Label(models.TextChoices):
        HOME = "home", "Home"
        WORK = "work", "Work"
        OTHER = "other", "Other"

    customer = models.ForeignKey(CustomerProfile, on_delete=models.CASCADE, related_name="addresses")
    label = models.CharField(max_length=10, choices=Label.choices, default=Label.HOME)
    contact_name = models.CharField(max_length=150, blank=True)
    contact_phone = models.CharField(max_length=16, blank=True)
    line1 = models.CharField(max_length=200)
    line2 = models.CharField(max_length=200, blank=True)
    landmark = models.CharField(max_length=200, blank=True)
    locality = models.CharField(max_length=120)
    city = models.CharField(max_length=80, default="Coimbatore")
    state = models.CharField(max_length=80, default="Tamil Nadu")
    pincode = models.CharField(max_length=6, validators=[PINCODE_VALIDATOR])
    latitude = latitude_field()
    longitude = longitude_field()
    is_default = models.BooleanField(default=False)
    is_active = models.BooleanField(default=True, help_text="Soft delete: bookings keep referencing old addresses.")

    class Meta:
        verbose_name_plural = "addresses"
        constraints = [
            models.UniqueConstraint(
                fields=["customer"], condition=Q(is_default=True, is_active=True), name="uniq_default_address_per_customer"
            )
        ]

    @property
    def owner_user_id(self):
        return self.customer.user_id

    def __str__(self):
        return f"{self.label}: {self.line1}, {self.locality}"
