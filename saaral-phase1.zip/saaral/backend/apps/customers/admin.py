from django.contrib import admin

from .models import Address, CustomerProfile


@admin.register(CustomerProfile)
class CustomerProfileAdmin(admin.ModelAdmin):
    list_display = ("user", "referral_code", "created_at")
    search_fields = ("user__phone", "user__full_name", "referral_code")


@admin.register(Address)
class AddressAdmin(admin.ModelAdmin):
    list_display = ("customer", "label", "locality", "pincode", "is_default", "is_active")
    list_filter = ("city", "is_active")
    search_fields = ("customer__user__phone", "locality", "pincode")
