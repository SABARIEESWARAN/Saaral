import pytest
from django.db import IntegrityError, transaction

from apps.customers.models import Address

pytestmark = pytest.mark.django_db


def test_only_one_default_address(make_user):
    profile = make_user("customer").customer_profile
    kw = dict(customer=profile, line1="a", locality="RS Puram", pincode="641002")
    Address.objects.create(is_default=True, **kw)
    Address.objects.create(is_default=False, **kw)
    with pytest.raises(IntegrityError), transaction.atomic():
        Address.objects.create(is_default=True, **kw)


def test_customer_gets_unique_referral_code(make_user):
    a, b = make_user("customer"), make_user("customer")
    assert a.customer_profile.referral_code != b.customer_profile.referral_code
    assert len(a.customer_profile.referral_code) == 8
