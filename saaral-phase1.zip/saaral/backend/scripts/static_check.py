"""Dependency-free structural checks (works without Django installed).

Verifies: every file compiles; every "app.Model" string reference in relations resolves; related_names
don't collide on the same target; each app has migrations/__init__.py. This is NOT a substitute for
`manage.py check`, `makemigrations --check` or the test-suite.
"""
import ast
import sys
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
APPS = ROOT / "apps"
REL = {"ForeignKey", "OneToOneField", "ManyToManyField"}
errors = []

# 1. compile everything
for path in ROOT.rglob("*.py"):
    if ".venv" in path.parts:
        continue
    try:
        compile(path.read_text(encoding="utf-8"), str(path), "exec")
    except SyntaxError as exc:
        errors.append(f"SYNTAX {path.relative_to(ROOT)}:{exc.lineno}: {exc.msg}")

# 2. collect models
models = {}  # "app.Model" -> (path, class node)
for mod in APPS.glob("*/models.py"):
    app = mod.parent.name
    tree = ast.parse(mod.read_text(encoding="utf-8"))
    for node in tree.body:
        if isinstance(node, ast.ClassDef):
            models[f"{app}.{node.name}"] = (mod, node, app)
models["accounts.User"] = models.get("accounts.User")

# 3. relation targets + related_name collisions
seen = defaultdict(list)
for key, val in models.items():
    if val is None:
        continue
    mod, cls, app = val
    for call in [n for n in ast.walk(cls) if isinstance(n, ast.Call)]:
        fn = call.func
        name = fn.attr if isinstance(fn, ast.Attribute) else getattr(fn, "id", "")
        if name not in REL:
            continue
        target = None
        if call.args and isinstance(call.args[0], ast.Constant) and isinstance(call.args[0].value, str):
            target = call.args[0].value
            if "." not in target:
                target = f"{app}.{target}"
        elif call.args and isinstance(call.args[0], ast.Name):
            target = f"{app}.{call.args[0].id}"
        elif call.args and isinstance(call.args[0], ast.Attribute):
            target = "accounts.User"  # settings.AUTH_USER_MODEL
        for kw in call.keywords:
            if kw.arg == "through" and isinstance(kw.value, ast.Constant):
                t = kw.value.value if "." in kw.value.value else f"{app}.{kw.value.value}"
                if t not in models:
                    errors.append(f"{key}: through={t!r} not found")
        if target and target not in models:
            errors.append(f"{key}: relation target {target!r} not found")
        rn = next((k.value.value for k in call.keywords if k.arg == "related_name" and isinstance(k.value, ast.Constant)), None)
        if rn and rn != "+":
            seen[(target, rn)].append(key)
for (target, rn), owners in seen.items():
    if len(owners) > 1:
        errors.append(f"related_name {rn!r} on {target} used by multiple models: {owners}")

# 4. migrations package present
for app_dir in sorted(p for p in APPS.iterdir() if (p / "models.py").exists()):
    if not (app_dir / "migrations" / "__init__.py").exists():
        errors.append(f"{app_dir.name}: migrations/__init__.py missing")

print(f"models found: {len([v for v in models.values() if v])}")
print("\n".join(errors) if errors else "static check: OK")
sys.exit(1 if errors else 0)
